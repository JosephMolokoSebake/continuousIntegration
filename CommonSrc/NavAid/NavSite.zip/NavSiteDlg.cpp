//---------------------------------------------------------------------------

#include <jpch.h>
#pragma hdrstop

#include "NavSiteDlg.h"
#include "Cst4SiteDefs.h"
#include "JColorDlg.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "NumEdit"
#pragma resource "*.dfm"
TNavSiteForm *NavSiteForm;
//---------------------------------------------------------------------------
__fastcall TNavSiteForm::TNavSiteForm(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TNavSiteForm::FormShow(TObject */*Sender*/)
{
	Site.Pack();
	SiteLB->Clear();
	for (int i=0; i<Site.nGetCount(); i++)
		SiteLB->Items->Add(Site[i]->sGetText());
	for (int i=0; i<Site.nGetCount(); i++)
		SiteLB->Checked[i]=Site[i]->bDisplay;
	nSite=-1;
	pSite=NULL;
	if (Site.nGetCount()>0)
		SetSite(0);
	else
		SetSite(-1);
	DelSiteBut->Enabled=(nSite>=0);
	OKBut->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TNavSiteForm::FormClose(TObject */*Sender*/, TCloseAction &/*Action*/)
{
	GetSite(nSite);
}

void TNavSiteForm::GetSite(const int n)
{
	if (n>=0)
		{
		pSite->SetText(DescrEd->Text);
		LatEd->GetVal(pSite->Pos.dLat);
		LongEd->GetVal(pSite->Pos.dLong);
		HeightEd->GetVal(pSite->nHeight_m);
		pSite->bDrawCircle=CoverChk->Checked;
		pSite->bAutoRa=AutoChk->Checked;
		MaxRaEd->GetVal(pSite->dMaxRa_km);
		WidthEd->GetVal(pSite->nLineWidth);
		pSite->bFill=FillChk->Checked;
		pSite->LineCol=LinePan->Color;
		pSite->FillCol=FillPan->Color;
		pSite->bDisplay=SiteLB->Checked[n];
		}
}

void TNavSiteForm::SetSite(const int n)
{
	if (nSite>=0)
		GetSite(nSite);
	nSite=n;
	if (nSite>=0)
		{
		SiteGrp->Enabled=true;
		pSite=Site[nSite];
		DescrEd->Text=pSite->sGetText();
		LatEd->SetVal(pSite->Pos.dLat);
		LongEd->SetVal(pSite->Pos.dLong);
		HeightEd->SetVal(pSite->nHeight_m);
		CoverChk->Checked=pSite->bDrawCircle;
		AutoChk->Checked=pSite->bAutoRa;
		MaxRaEd->SetVal(pSite->dMaxRa_km);
		WidthEd->SetVal(pSite->nLineWidth);
		FillChk->Checked=pSite->bFill;
		LinePan->Color=pSite->LineCol;
		FillPan->Color=pSite->FillCol;
		SymbolBut->Enabled=true;
		SiteLB->Checked[nSite]=pSite->bDisplay;
		CoverChkClick(0);
		}
	else
		{
		SiteGrp->Enabled=false;
		pSite=NULL;
		DescrEd->Text="";
		LatEd->Text="";
		LongEd->Text="";
		HeightEd->Text="";
		CoverChk->Checked=false;
		AutoChk->Checked=false;
		MaxRaEd->Text="";
		WidthEd->Text="";
		FillChk->Checked=false;
		LinePan->Color=clLtGray;
		FillPan->Color=clLtGray;
		SymbolBut->Enabled=false;
		}
	SiteLB->ItemIndex=nSite;
	DelSiteBut->Enabled=(nSite>=0);
	UpBut->Enabled=(SiteLB->ItemIndex>0);
	DownBut->Enabled=(SiteLB->ItemIndex>=0)&&(SiteLB->ItemIndex<SiteLB->Count-1);
}

//---------------------------------------------------------------------------
void __fastcall TNavSiteForm::AddSiteButClick(TObject */*Sender*/)
{
	if (nSite>=0)
		GetSite(nSite);
	Site.nAdd(new NavSiteStruct);
	SiteLB->Items->Add("");
	SiteLB->Checked[SiteLB->Count-1]=true;
	Site.Pack();
	pSite=Site[Site.nGetCount()-1];
	nSite=-1;
	SetSite(Site.nGetCount()-1);
	DescrEd->SetFocus();
	DelSiteBut->Enabled=(nSite>=0);
}
//---------------------------------------------------------------------------

void __fastcall TNavSiteForm::DelSiteButClick(TObject */*Sender*/)
{
	Site.Delete(nSite);
	Site.Pack();
	nSite-=1;
	if (nSite<0)
		{
		if (Site.nGetCount()>0)
			nSite=0;
		}
	int n=nSite;
	nSite=-1;
	SetSite(n);
	DelSiteBut->Enabled=(nSite>=0);
}
//---------------------------------------------------------------------------

void __fastcall TNavSiteForm::SymbolButClick(TObject */*Sender*/)
{
	if (pSite)
		{
		pSite->SetText(DescrEd->Text);
		LatEd->GetVal(pSite->Pos.dLat);
		LongEd->GetVal(pSite->Pos.dLong);
		pSite->bEditSiteSymbol();
		}
}
//---------------------------------------------------------------------------

void __fastcall TNavSiteForm::LinePanClick(TObject */*Sender*/)
{
	LinePan->Color=SelectColor("Circle Line Colour",LinePan->Color,clBlack);
}
//---------------------------------------------------------------------------

void __fastcall TNavSiteForm::FillPanClick(TObject */*Sender*/)
{
	FillPan->Color=SelectColor("Circle Fill Colour",FillPan->Color,clBlack);
}
//---------------------------------------------------------------------------

void __fastcall TNavSiteForm::CoverChkClick(TObject *Sender)
{
	AutoChk->Enabled=CoverChk->Checked;
	AutoChkClick(Sender);
	LineLab->Enabled=CoverChk->Checked;
	WidthEd->Enabled=CoverChk->Checked;
	LinePan->Enabled=CoverChk->Checked;
	FillChk->Enabled=CoverChk->Checked;
	FillPan->Enabled=CoverChk->Checked;
	FillChkClick(Sender);
}
//---------------------------------------------------------------------------

void __fastcall TNavSiteForm::AutoChkClick(TObject */*Sender*/)
{
	RaLab1->Enabled=CoverChk->Checked && !AutoChk->Checked;
	RaLab2->Enabled=CoverChk->Checked && !AutoChk->Checked;
	MaxRaEd->Enabled=CoverChk->Checked && !AutoChk->Checked;
	CalcMaxRa();

}
//---------------------------------------------------------------------------

void TNavSiteForm::CalcMaxRa()
{
	if (AutoChk->Checked)
		{
		double dHgt_m=HeightEd->dGetVal();
		if (dHgt_m>=0)
			{
			double dRa_km=sqrt(16.79*(dHgt_m+25.0));
			MaxRaEd->SetVal(dRa_km);
			}
		}
}

void __fastcall TNavSiteForm::HeightEdChange(TObject *Sender)
{
	AutoChkClick(Sender);
}
//---------------------------------------------------------------------------

void __fastcall TNavSiteForm::FillChkClick(TObject */*Sender*/)
{
	FillPan->Enabled=CoverChk->Checked && FillChk->Checked;
}
//---------------------------------------------------------------------------

void __fastcall TNavSiteForm::DescrEdChange(TObject */*Sender*/)
{
	if (nSite>=0)
		{
		SiteLB->Items->Strings[nSite]=DescrEd->Text;
		}
}
//---------------------------------------------------------------------------

void __fastcall TNavSiteForm::SiteLBClick(TObject */*Sender*/)
{
	int n=SiteLB->ItemIndex;
	if (n>=0)
		{
		SetSite(n);
		}
}
//---------------------------------------------------------------------------

void __fastcall TNavSiteForm::UpButClick(TObject */*Sender*/)
{
	int n=SiteLB->ItemIndex;
	if (n>0)
		{
		GetSite(n);
		SiteLB->Items->Exchange(n,n-1);
		Site.Exchange(n,n-1);
		nSite=-1;
		SetSite(n-1);
		}
}
//---------------------------------------------------------------------------

void __fastcall TNavSiteForm::DownButClick(TObject */*Sender*/)
{
	int n=SiteLB->ItemIndex;
	if ((n>=0)&&(n<SiteLB->Count-1))
		{
		GetSite(n);
		SiteLB->Items->Exchange(n,n+1);
		Site.Exchange(n,n+1);
		nSite=-1;
		SetSite(n+1);
		}
}
//---------------------------------------------------------------------------

void __fastcall TNavSiteForm::RefreshButClick(TObject */*Sender*/)
{
	Cst4SiteDefs Sites;
	if (Sites.bLoad())
		{
		for (int nCountry=0; nCountry<Sites.nGetCountryCnt(); nCountry++)
			{
			for (int nLoc=0; nLoc<Sites.nGetLocCnt(nCountry); nLoc++)
				{
				String sLoc=Sites.sGetLocation(nCountry,nLoc);
				WORD wID=Sites.wGetIDFromRaw(nCountry,nLoc,0);
				LatLong LL;
				LL.Invalidate();
				int nHeight_m=0;
				for (int nType=0; (nType<Sites.nGetTypeCnt(nCountry,nLoc)) && !LL.bValid(); nType++)
					{
					LL=Sites.GetLL(nCountry,nLoc,nType);
					if (LL.bValid())
						nHeight_m=Sites.nGetHeight_m(nCountry,nLoc,nType);
					}
				if (!sLoc.IsEmpty()&&LL.bValid())
					{
					Site.Pack();
					int nFound=-1;
					for (int i=0; i<Site.nGetCount(); i++)
						{
						if (Site[i]->wID==wID)
							{
							nFound=i;
							i=Site.nGetCount();
							}
						}
					if (nFound>=0)
						{
						Site[nFound]->SetText(sLoc);
						Site[nFound]->SetPos(LL);
						Site[nFound]->nHeight_m=nHeight_m;
						}
					else
						{
						NavSiteStruct* pS=new NavSiteStruct;
						pS->wID=wID;
						pS->nHeight_m=nHeight_m;
						pS->SetText(sLoc);
						pS->SetPos(LL);
						Site.nAdd(pS);
						Site.Pack();
						}
					}
				}
			}

		}
	SiteLB->Clear();
	for (int i=0; i<Site.nGetCount(); i++)
		SiteLB->Items->Add(Site[i]->sGetText());
	for (int i=0; i<Site.nGetCount(); i++)
		SiteLB->Checked[i]=Site[i]->bDisplay;
	nSite=-1;
	pSite=NULL;
	if (Site.nGetCount()>0)
		SetSite(0);
	else
		SetSite(-1);
	DelSiteBut->Enabled=(nSite>=0);
	OKBut->SetFocus();
}
//---------------------------------------------------------------------------

