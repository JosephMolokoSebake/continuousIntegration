//---------------------------------------------------------------------------
#include "jpch.h"
#pragma hdrstop

#include "NavSite.h"
#include "NavSiteDlg.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)

#ifdef __DDGRAPH
	void NavSiteStruct::CalcPix(DDGraph* pG)
	{
		PixPos=pG->LL2Pix(Pos);
		if (bDrawCircle)
			{
			XYPos XY1=pG->LL2XY(Pos);
			XYPos XY2=XY1;
			XY2.dx+=dMaxRa_km*1000.0;
			Pixel Pix2=pG->XY2Pix(XY2);
			int nRa=abs(Pix2.nx-PixPos.nx);
			if (nRa<1)
				nRa=1;
			R.Left=PixPos.nx-nRa;
			R.Top=PixPos.ny-nRa;
			R.Right=PixPos.nx+nRa;
			R.Bottom=PixPos.ny+nRa;
			}
	}
#else
	void NavSiteStruct::CalcPix(TransGraph* pG)
	{
		PixPos=pG->LL2Pix(Pos);
		if (bDrawCircle)
			{
			XYPos XY1=pG->LL2XY(Pos);
			XYPos XY2=XY1;
			XY2.dx+=dMaxRa_km*1000.0;
			Pixel Pix2=pG->XY2Pix(XY2);
			int nRa=abs(Pix2.nx-PixPos.nx);
			if (nRa<1)
				nRa=1;
			R.Left=PixPos.nx-nRa;
			R.Top=PixPos.ny-nRa;
			R.Right=PixPos.nx+nRa;
			R.Bottom=PixPos.ny+nRa;
			}
	}
#endif


void NavSiteStruct::DrawSite(HDC DC, const TColor BackColor)
{
	if (bDisplay)
		SymbolStruct::Draw(DC,BackColor);
}

void NavSiteStruct::DrawArea(HDC DC)
{
	if ((bDrawCircle)&&(bDisplay))
		{
		HBRUSH hBrush;
		if (bFill)
			hBrush=::CreateSolidBrush(g_GetColor(FillCol));
		else
			hBrush=(HBRUSH)::GetStockObject(NULL_BRUSH);
		HPEN hPen=::CreatePen(PS_SOLID,nLineWidth,g_GetColor(LineCol));
		HBRUSH hOldBrush=(HBRUSH)::SelectObject(DC,hBrush);
		HPEN hOldPen=(HPEN)::SelectObject(DC,hPen);
		::Ellipse(DC,R.Left,R.Top,R.right,R.Bottom);
		::SelectObject(DC,hOldBrush);
		::DeleteObject(hBrush);
		::SelectObject(DC,hOldPen);
		::DeleteObject(hPen);
		}
}

void NavSiteStruct::Store(JIniFile* pFil, const int n)
{
	Store(pFil,"NAVSITE "+String(n));
}

void NavSiteStruct::Store(JIniFile* pFil, const String sName)
{
	SymbolStruct::Store(pFil,sName);
	pFil->Write("ID",(int)dwID);
	pFil->Write("Height",nHeight_m);
	pFil->Write("Auto Range",bAutoRa);
	pFil->Write("Max Range",dMaxRa_km);
	pFil->Write("Draw Circle",bDrawCircle);
	pFil->Write("Line Colour",LineCol);
	pFil->Write("Line Width",nLineWidth);
	pFil->Write("Fill Area",bFill);
	pFil->Write("Fill Colour",FillCol);
}

void NavSiteStruct::Read(JIniFile* pFil, const int n)
{
	Read(pFil,"NAVSITE "+String(n));
}

void NavSiteStruct::Read(JIniFile* pFil, const String sName)
{
	SymbolStruct::Read(pFil,sName);
	dwID=pFil->dwRead("ID",0);
	pFil->Read("Height",nHeight_m,0);
	pFil->Read("Auto Range",bAutoRa,true);
	pFil->Read("Max Range",dMaxRa_km,1.0);
	pFil->Read("Draw Circle",bDrawCircle,true);
	pFil->Read("Line Colour",LineCol,clLtGray);
	pFil->Read("Line Width",nLineWidth,1);
	pFil->Read("Fill Area",bFill,true);
	pFil->Read("Fill Colour",FillCol,clGray);
}

NavSites::NavSites()
{
}

NavSites::~NavSites()
{
}

void NavSites::Edit(TForm* pOwner)
{
	NavSiteForm=new TNavSiteForm(pOwner);
	NavSiteForm->Site=Site;
	if (NavSiteForm->ShowModal()==mrOk)
		Site=NavSiteForm->Site;
	delete NavSiteForm;
}

void NavSites::Store(const String sFile)
{
	JIniFile Ini(true,sFile);
	Store(&Ini);
}

void NavSites::Read(const String sFile)
{
	JIniFile Ini(false,sFile);
	Read(&Ini);
}

void NavSites::Store(JIniFile* pIni)
{
	Site.Pack();
	pIni->Write("NAV SITE DISPLAY","Site Count",Site.nGetCount());
	for (int i=0; i<Site.nGetCount(); i++)
		Site[i]->Store(pIni,i);
}

void NavSites::Read(JIniFile* pIni)
{
	int n;
	Site.Clear();
	pIni->Read("NAV SITE DISPLAY","Site Count",n,0);
	for (int i=0; i<n; i++)
		{
		NavSiteStruct* pS=new NavSiteStruct;
		pS->Read(pIni,i);
      Site.nAdd(pS);
		}
	Site.Pack();
}

#ifdef __DDGRAPH
	void NavSites::CalcPix(DDGraph* pG)
	{
		for (int i=0; i<Site.nGetCount(); i++)
			Site[i]->CalcPix(pG);
	}
#else
	void NavSites::CalcPix(TransGraph* pG)
	{
		for (int i=0; i<Site.nGetCount(); i++)
			Site[i]->CalcPix(pG);
	}
#endif


void NavSites::DrawSites(HDC DC, const TColor BackColor)
{
	for (int i=0; i<Site.nGetCount(); i++)
		{
		Site[i]->CalcSize(DC);
		Site[i]->DrawSite(DC,BackColor);
		}
}

void NavSites::DrawAreas(HDC DC)
{
	for (int i=0; i<Site.nGetCount(); i++)
		Site[i]->DrawArea(DC);
}

void NavSites::Refresh(const DWORD dwID, const String sDescr, const LatLong&& LL, const int nHeight_m)
{
	Site.Pack();
	int nFound=-1;
	for (int i=0; i<Site.nGetCount(); i++)
		{
		if (Site[i]->dwID==dwID)
			{
			nFound=i;
			i=Site.nGetCount();
			}
		}
	if (nFound>=0)
		{
		Site[nFound]->SetText(sDescr);
		Site[nFound]->SetPos(LL);
		Site[nFound]->nHeight_m=nHeight_m;
		}
	else
		{
		NavSiteStruct* pS=new NavSiteStruct;
		pS->dwID=dwID;
		pS->nHeight_m=nHeight_m;
		pS->SetText(sDescr);
		pS->SetPos(LL);
		Site.nAdd(pS);
		Site.Pack();
		}
}

