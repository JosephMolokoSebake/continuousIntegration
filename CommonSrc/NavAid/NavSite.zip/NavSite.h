//---------------------------------------------------------------------------
#ifndef NavSiteH
#define NavSiteH
//---------------------------------------------------------------------------
#include "NavAid.h"
#include "JList.h"

struct NavSiteStruct : public SymbolStruct
{

	int nHeight_m;
	bool bDrawCircle;
	bool bAutoRa;
	double dMaxRa_km;
	TRect R;
	TColor LineCol;
	int nLineWidth;
	bool bFill;
	TColor FillCol;
	DWORD dwID;

	NavSiteStruct()
	{
		nHeight_m=0;
		bDrawCircle=false;
		bAutoRa=false;
		dMaxRa_km=1.0;
		R=TRect(0,0,1,1);
		LineCol=clLtGray;
		nLineWidth=1;
		bFill=true;
		FillCol=clGray;
		dwID=0;
		SymbolStruct::Init();

		pFont->Name="Arial";
		pFont->Size=12;
		pFont->Color=clWhite;
		bDispSymbol=true;
		Symbol=CIRCLE_SYM;
		nSymbolSize=4;
		SymbolColor=clLime;
		TextAlign=SymbolStruct::AL_TOP;
		bSolidFill=false;
		bDispText=true;
		bSolidBack=false;
		bLocked=false;
		bRef=false;
		bDisplay=true;
	}

	NavSiteStruct(const NavSiteStruct& S)
	{
		*this=S;
	}

	NavSiteStruct& operator = (const NavSiteStruct& S)
	{

		SymbolStruct::operator =(S);
		nHeight_m=S.nHeight_m;
		bDrawCircle=S.bDrawCircle;
		bAutoRa=S.bAutoRa;
		dMaxRa_km=S.dMaxRa_km;
		R=S.R;
		LineCol=S.LineCol;
		nLineWidth=S.nLineWidth;
		bFill=S.bFill;
		FillCol=S.FillCol;
		dwID=S.dwID;
		return *this;
	}

	~NavSiteStruct()
	{

	}

#ifdef __DDGRAPH
	void CalcPix(DDGraph* pG);
#else
	void CalcPix(TransGraph* pG);
#endif

	void DrawSite(HDC DC, const TColor BackColor);
	void DrawArea(HDC DC);

	void Store(JIniFile* pFil, const int n);
	void Store(JIniFile* pFil, const String sName);
	void Read(JIniFile* pFil, const int n);
	void Read(JIniFile* pFil, const String sName);

};

class NavSites
{

	JList<NavSiteStruct> Site;

public:

	NavSites();
	~NavSites();

	NavSites& operator = (const NavSites& S)
	{
		Site=S.Site;
		return *this;
	}

	void Edit(TForm* pOwner=NULL);

	void Store(const String sFile);
	void Read(const String sFile);

	void Store(JIniFile* pIni);
	void Read(JIniFile* pIni);

#ifdef __DDGRAPH
	void CalcPix(DDGraph* pG);
#else
	void CalcPix(TransGraph* pG);
#endif

	void DrawSites(HDC DC, const TColor BackColor);
	void DrawAreas(HDC DC);

	void Refresh(const DWORD dwID, const String sDescr, const LatLong&& LL, const int nHeight_m);


};



#endif
