//---------------------------------------------------------------------------

#ifndef Cst4TWSH
#define Cst4TWSH
//---------------------------------------------------------------------------

#include "Cst4Messages.h"
#include "JIniFile.h"
#include "JFile.h"

struct Cst4_TWSSetupStruct
{
//Filter
	double dAlpha;
	int nMAFilter;

//Target
	int nMaxSpeed_kts;

//Acquisition
	int nAcqMissedAbort;
	int nAcqIncPerc;
	int nAcqIncScans;
	int nAcqDecPerc;
	int nAcqDecScans;

//Solid
	int nSolidMissedAbort;
	int nSolidIncPerc;
	int nSolidIncScans;
	int nSolidDecPerc;
	int nSolidDecScans;

//Health
	int nMinHealth;
	int nMaxHealth;

//Radar Errors
	double dRaErr_m;
	double dBeErr_deg;

//Scan Correlation
	bool bCorr;
	int nCorrScans;
	int nCorrPercent;

	Cst4_TWSSetupStruct()
	{
		dAlpha=0.1;
		nMAFilter=20;
		nMaxSpeed_kts=50;
		bCorr=false;
		nCorrScans=5;
		nCorrPercent=60;
		nMinHealth=15;
		nMaxHealth=30;

		nAcqMissedAbort=3;
		nAcqIncPerc=100;
		nAcqIncScans=1;
		nAcqDecPerc=0;
		nAcqDecScans=1;

		nSolidMissedAbort=6;
		nSolidIncPerc=100;
		nSolidIncScans=1;
		nSolidDecPerc=0;
		nSolidDecScans=1;

		dRaErr_m=300.0;
		dBeErr_deg=1.5;
	}

	void Assign(Cst4_TWSSetupStruct& T)
	{
		dAlpha=T.dAlpha;
		nMaxSpeed_kts=T.nMaxSpeed_kts;
		nMAFilter=T.nMAFilter;
		bCorr=T.bCorr;
		nCorrScans=T.nCorrScans;
		nCorrPercent=T.nCorrPercent;
		nMinHealth=T.nMinHealth;
		nMaxHealth=T.nMaxHealth;

		nAcqMissedAbort=T.nAcqMissedAbort;
		nAcqIncPerc=T.nAcqIncPerc;
		nAcqIncScans=T.nAcqIncScans;
		nAcqDecPerc==T.nAcqDecPerc;
		nAcqDecScans=T.nAcqDecScans;

		nSolidMissedAbort=T.nSolidMissedAbort;
		nSolidIncPerc=T.nSolidIncPerc;
		nSolidIncScans=T.nSolidIncScans;
		nSolidDecPerc==T.nSolidDecPerc;
		nSolidDecScans=T.nSolidDecScans;

		dRaErr_m=T.dRaErr_m;
		dBeErr_deg=T.dBeErr_deg;
	}


	Cst4_TWSSetupStruct& operator = (Cst4_TWSSetupStruct& T)
	{
		Assign(T);
		return *this;
	}

	void Store(JIniFile* pIni, const String sHeading);
	void Read(JIniFile* pIni, const String sHeading);

	double dSqr(const double dV) const
	{
		return dV*dV;
	}

	double dATan_rad(const double dy, const double dx) const
	{
		if (fabs(dx)<1.0)
			{
			if (dy<0.0)
				return M_PI*3.0/2.0;	//270 deg
			return M_PI/2.0;			//90 deg
			}
		return atan2(dy,dx);
	}

	double dNormalise_rad(double dBe_rad) const
	{
		if (dBe_rad>M_PI*2.0)
			return dBe_rad-M_PI*2.0;
		if (dBe_rad<0.0)
			return dBe_rad+M_PI*2.0;
		return dBe_rad;
	}

	//Additional distance in tracking gate
	double dCalcSpeedRadius_m(const int nHealth, const double dDeltaT_sec)  const
	{
		double dExpandFact;
		if (nHealth<=nMinHealth)
			dExpandFact=1.0;
		else if (nHealth>=nMaxHealth)
			dExpandFact=0.0;
		else
			dExpandFact=1.0-((nHealth-nMinHealth)*1.0)/(nMaxHealth-nMinHealth);
		return 2.0*nMaxSpeed_kts*dDeltaT_sec*dExpandFact;
	}

	double dCalcErrRadius_m(const double dTargetRa_m) const
	{
		return sqrt(dSqr(2.0*dRaErr_m)+dSqr(2.0*dTargetRa_m*dBeErr_deg*M_PI/180.0));
	}

	double dCalcMaxRadius_m(const int nHealth, const double dDeltaT_sec, const double dTargetRa_m) const
	{
		return dCalcErrRadius_m(dTargetRa_m)+dCalcSpeedRadius_m(nHealth,dDeltaT_sec);
	}

	bool bInRaGate(const double dRa, const double dRa1, const double dRa2) const	//units not used
	{
		return (dRa>=dRa1)&&(dRa<=dRa2);
	}

	bool bInBeGate(const double dBe, const double dBe1, const double dBe2) const	//units not used
	{
		if (dBe2>dBe1)
			return (dBe>=dBe1)&&(dBe<=dBe2);
		else
			return (dBe>=dBe1)||(dBe<=dBe2);
	}



	bool bInErrorGate(const XYPos& Predict, const XYPos& Actual) const
	{
		double dRa_m=sqrt(dSqr(Actual.dx)+dSqr(Actual.dy));
		double dRa1_m=sqrt(dSqr(Predict.dx)+dSqr(Predict.dy));
		double dRa2_m=dRa1_m+dRaErr_m;
		dRa1_m-=dRaErr_m;
		if (!bInRaGate(dRa_m,dRa1_m,dRa2_m))
			return false; 	//outside range error
		double dBe_rad=dATan_rad(Actual.dy,Actual.dx);
		double dBe1_rad=dATan_rad(Predict.dy,Predict.dx);
		double dBe2_rad=dNormalise_rad(dBe1_rad+dBeErr_deg*M_PI/180.0);
		dBe1_rad=dNormalise_rad(dBe1_rad-dBeErr_deg*M_PI/180.0);
		return bInBeGate(dBe_rad,dBe1_rad,dBe2_rad);
	}


	bool bInGate(const XYPos& Predict, const XYPos& Actual, const double dSpeedRadius_m, const double dMaxRadius_m, double& dDist_m);

	bool bInGate(const XYPos& Predict, const XYPos& Actual, const double dSpeedRadius_m, const double dMaxRadius_m)
	{
		double dDist_m;	//not used
		return bInGate(Predict,Actual,dSpeedRadius_m,dMaxRadius_m,dDist_m);
	}



};

class Cst4_TWS_History
{

	DWORD dwHist;
	BYTE ucIncScans;
	BYTE ucDecScans;
	BYTE ucIncValid;
	BYTE ucDecValid;
	BYTE ucMaxLen;
	BYTE ucLen;

	int nMissedAbort;
	int nMissed;
	int nMaxHealth;

	JFile* pTFil;


public:

	Cst4_TWS_History()
	{
		ucIncScans=0;
		ucDecScans=0;
		dwHist=0;
		ucLen=0;
		nMissed=0;
		pTFil=NULL;
	}

	void Init(	const int nIncPerc, const int nIncScans,
					const int nDecPerc, const int nDecScans,
					const int nAbortCnt, const int _nMaxHealth, JFile* pFil)
	{
		ucIncScans=(BYTE)nIncScans;
		ucIncValid=(BYTE)((nIncPerc*nIncScans)/100.0+0.5);
		ucDecScans=(BYTE)nDecScans;
		ucDecValid=(BYTE)((nDecPerc*nIncScans)/100.0+0.5);
		if (ucIncScans>ucDecScans)
			ucMaxLen=ucIncScans;
		else
			ucMaxLen=ucDecScans;
		nMissedAbort=nAbortCnt;
		nMaxHealth=_nMaxHealth;
		dwHist=0;
		ucLen=0;
		nMissed=0;
		pTFil=pFil;
	}

	void AddScan()
	{
		dwHist<<=1;
		dwHist|=0x00000001;
		if (ucLen<ucMaxLen)
			++ucLen;
		nMissed=0;
	}

	void SkipScan()
	{
		dwHist<<=1;
		if (ucLen<ucMaxLen)
			++ucLen;
		++nMissed;
	}

	void UpdateHealth(int& nHealth)
	{
		if (ucLen>0)
			{
			int nIncr=0;
			if (nHealth<nMaxHealth)
				{
				BYTE ucTot=0;
				for (BYTE uc=0; uc<ucIncScans; uc++)
					if (dwHist&(1<<uc))
						++ucTot;
				if (ucTot>=ucIncValid)
					nIncr=1;
				if (pTFil)
					{
					String s;
					s.printf(L"     -- Health Incr: %d/%d (Valid %d) Incr=%d",ucTot,ucIncScans,ucIncValid,nIncr);
					pTFil->TextLine(s);
					}
				}
			if ((nHealth>0)&&(nIncr==0))
				{
				BYTE ucTot=0;
				for (BYTE uc=0; uc<ucDecScans; uc++)
					if (dwHist&(1<<uc))
						++ucTot;
				if (ucTot<=ucDecValid)
					nIncr=-1;
				if (pTFil)
					{
					String s;
					s.printf(L"     -- Health Decr: %d/%d (Valid %d) Incr=%d",ucTot,ucDecScans,ucDecValid,nIncr);
					pTFil->TextLine(s);
					}
				}
			nHealth+=nIncr;
			}
	}

	bool bAbort() const
	{
		return (nMissed>=nMissedAbort);
	}

	String sStatus()
	{
		String s;
		s.printf(L"   Inc: %2d Dec: %2d  Missed: %2d  ",ucIncScans,ucDecScans,nMissed);

		String sH="";
		for (int i=0; i<16; i++)
			{
			if ((1<<i)&dwHist)
				sH="1"+sH;
			else
				sH="0"+sH;
			}
		return s+sH;
   }

};


class Cst4_TWS_Track
{

	JFile* pTFil;

	Cst4_TWSSetupStruct* pSetup;
	Transform* pTrans;

	Cst4_TWS_History SolidHist;
	Cst4_TWS_History AcqHist;

	WORD wSource;

	int nTrackID;
	Cst4_Radar_Track* pTrackMsg;

	double dBeta;
	double dMaxVel_mps;

	XYPos StartXY,PredXY,VelXY,SmoothedXY;
	Polar PredPol;

//   double dMinRa_m,dMaxRa_m,dMinBe_deg,dMaxBe_deg;

	double dScanTime_sec;
	double dSpeedRadius_m;
	double dMaxRadius_m;
//	int nPlotNum;
//	Polar InPol;
	double dMinDist_m;
	XYPos InXY;

   //	int nSkipped;
	int nCount;
	int nValid;
	double dPrevTime_sec;
	int nHealth;
	bool bSolid;
	bool bSmoothValid;



	bool bForceAbort;

	XYPos* pMABuf;
	double* pdMATime_sec;
	XYPos* pMAVel;
	int nMACnt;
	int nMAIndex;
	XYPos MATot;
	XYPos MAVelTot;

	void Next(const double dTime_sec, const XYPos& XY);
	void NextPos(const double dTime_sec, const XYPos& XY, int& nCurrentID);
	void NextPos(const double dTime_sec);

	double dSqr(const double dV) const
	{
		return dV*dV;
	}

/*
	void CalcNextWindow()
	{
		double dExpandFact;
		if (nHealth<=pSetup->nMinHealth)
			dExpandFact=pSetup->dMaxExpand;
		else if (nHealth>=pSetup->nMaxHealth)
			dExpandFact=1.0;
		else
			{
			dExpandFact=((nHealth-pSetup->nMinHealth)*1.0)/(pSetup->nMaxHealth-pSetup->nMinHealth);
			dExpandFact=(1.0-dExpandFact)*(pSetup->dMaxExpand-1.0)+1.0;
			}
		dMaxRa_m=pSetup->RadarError.dRa*dExpandFact+PredPol.dRa;
		dMinRa_m=PredPol.dRa-pSetup->RadarError.dRa*dExpandFact;
		dMaxBe_deg=pSetup->RadarError.dBe*dExpandFact+PredPol.dBe;
		if (dMaxBe_deg>=360.0)
			dMaxBe_deg-=360.0;
		else if (dMaxBe_deg<0.0)
			dMaxBe_deg+=360.0;
		dMinBe_deg=PredPol.dBe-pSetup->RadarError.dBe*dExpandFact;
		if (dMinBe_deg>=360.0)
			dMinBe_deg-=360.0;
		else if (dMinBe_deg<0.0)
			dMinBe_deg+=360.0;
	}
*/

/*
	double dCalcDist_m(const Polar& Pol)
	{
		double dExpandFact;
		if (nHealth<=pSetup->nMinHealth)
			dExpandFact=pSetup->dMaxExpand;
		else if (nHealth>=pSetup->nMaxHealth)
			dExpandFact=1.0;
		else
			{
			dExpandFact=((nHealth-pSetup->nMinHealth)*1.0)/(pSetup->nMaxHealth-pSetup->nMinHealth);
			dExpandFact=(1.0-dExpandFact)*(pSetup->dMaxExpand-1.0)+1.0;
			}
		XYPos ActXY=pTrans->Pol2XY(Pol);
		XYPos PredXY=pTrans->Pol2XY(PredPol);
		double dMaxMove_m=dMaxVel_mps;
		if (pSetup->bInGate(PredXY,ActXY,dMaxMove_m))
			{
			return sqrt(dSqr(ActXY.dx-PredXY.dx)+dSqr(ActXY.dy-PredXY.dy));
			}
		return 1e20;
	}
*/

	double dMAFilter_sec(const XYPos& XY, const XYPos& Vel, const double dT_sec, XYPos& XY_Filt, XYPos& Vel_Filt);


public:

	Cst4_TWS_Track(Cst4_TWSSetupStruct* _pSetup, Transform* _pTrans, Cst4Plot* pPlot, const double dT_sec, const WORD _wSource)
	{
		memset(this,0,sizeof(Cst4_TWS_Track));
		pMABuf=NULL;
		pdMATime_sec=NULL;
		pMAVel=NULL;
		pSetup=_pSetup;
		pTrans=_pTrans;

		pTFil=NULL;
		pTFil=new JFile('O',JFile::ASCII_TYPE);

		if (pTFil)
			{
			static int nF=0;
			String s;
			s.printf(L"Track Test %05d.txt",nF++);
			pTFil->Create(s);
			}

		AcqHist.Init(pSetup->nAcqIncPerc,pSetup->nAcqIncScans,
							pSetup->nAcqDecPerc,pSetup->nAcqDecScans,
							pSetup->nAcqMissedAbort,pSetup->nMaxHealth,pTFil);
		SolidHist.Init(pSetup->nSolidIncPerc,pSetup->nSolidIncScans,
							pSetup->nSolidDecPerc,pSetup->nSolidDecScans,
							pSetup->nSolidMissedAbort,pSetup->nMaxHealth,pTFil);
		pTrackMsg=new Cst4_Radar_Track;
		ResetFilters();
		Polar Pol(pPlot->dRa_m(),pPlot->dBe_deg());
		PredPol=Pol;
		StartXY=pTrans->Pol2XY(Pol);
		PredXY=StartXY;
		dPrevTime_sec=dT_sec;
		wSource=_wSource;
		nTrackID=-1; 	//will only get ID if Acq track
		dBeta=2.0*(2.0-pSetup->dAlpha)-4.0*sqrt(1.0-pSetup->dAlpha);
		dMaxVel_mps=pSetup->nMaxSpeed_kts/2.0;
		VelXY=XYPos(0.0,0.0);
		nCount=0;
//      nSkipped=0;
		bSolid=false;
		nHealth=0;
		bSmoothValid=false;

	}

	~Cst4_TWS_Track()
	{
		delete[] pMAVel;
		delete[] pdMATime_sec;
		delete[] pMABuf;
		delete pTrackMsg;
		delete pTFil;
	}

	void Assign(Cst4_TWS_Track& M)
	{


//      Setup=M.Setup;
   }

   Cst4_TWS_Track& operator = (Cst4_TWS_Track& M)
   {
      Assign(M);
      return *this;
   }

   Cst4_TWS_Track(Cst4_TWS_Track& M)
   {
      Assign(M);
   }

   void ResetFilters()
	{
		VelXY=XYPos(0.0,0.0);
		delete[] pdMATime_sec;
		delete[] pMABuf;
		delete[] pMAVel;
		pMABuf=new XYPos[pSetup->nMAFilter];
		pdMATime_sec=new double[pSetup->nMAFilter];
		pMAVel=new XYPos[pSetup->nMAFilter];
		MATot=XYPos(0.0,0.0);
		MAVelTot=XYPos(0.0,0.0);
		nMACnt=0;
		nMAIndex=0;
	}

	void InitScan(const double dT_sec)
	{
		dScanTime_sec=dT_sec;
		dMinDist_m=1e10;
//		nPlotNum=-1;
		InXY.Invalidate();
		dSpeedRadius_m=pSetup->dCalcSpeedRadius_m(nHealth,dScanTime_sec-dPrevTime_sec);
		dMaxRadius_m=pSetup->dCalcErrRadius_m(PredPol.dRa)+dSpeedRadius_m;
	}

   bool bAddPlot(const XYPos XY)
   {
//   	if (pSetup->bInGate(PredXY,XY,dSpeedRadius_m,dMaxRadius_m))
			{
			InXY=XY;
			return true;
			}
/*
		else
			{
			InXY.Invalidate();
			return false;
			}
*/
   }

/*
	void AddPlot(const Cst4Plot* pPlot, const int n)
	{
		Polar Pol(pPlot->dRa_m(),pPlot->dBe_deg());
		XYPos XY=pTrans->Pol2XY(Pol);
		double dDist_m=-1.0;
		if (pSetup->bInGate(PredXY,XY,dSpeedRadius_m,dMaxRadius_m,dDist_m))
			{
			if (dDist_m<dMinDist_m)
				{
				dMinDist_m=dDist_m;
				nPlotNum=n;
				InPol=Pol;
				}
			}
		if (pTFil)
			{
			String s;
			s.printf(L"    P(%0.0f,%0.0f), A(%0.0f,%0.0f), SR=%0.0f, MR=%0.0f, D=%0.0f, #=%d",PredXY.dx,PredXY.dy,XY.dx,XY.dy,dSpeedRadius_m,dMaxRadius_m,dDist_m,nPlotNum);
			pTFil->TextLine(s);
			}
	}

	void AddPlot(const Cst4Plot& Plot, const int n)
	{
		AddPlot(&Plot,n);
	}

	int nUsedPlotNum() const
	{
		return nPlotNum;
	}

	void ClearPlot()
	{
		nPlotNum=-1;
	}
*/

	double dPlotMinDist_m() const
	{
		return dMinDist_m;
	}

	void CalcTrack(int& nCurrentID);

	Cst4_Radar_Track& GetTrackMsg()
	{
      return *pTrackMsg;
   }

   Cst4_Radar_Track* pGetTrackMsg()
   {
      return pTrackMsg;
   }

	bool bAborted() const
	{
		if (bSolid)
			return (SolidHist.bAbort() || (nHealth<=0) || bForceAbort);
		else
			return (AcqHist.bAbort() || bForceAbort) || (nHealth<0);
	}

	bool bSolidTrack() const
	{
		return bSolid;
   }

	int nGetHealth() const
   {
      return nHealth; 
   }

   int nGetID() const
	{
		return nTrackID;
	}

	XYPos GetPredXY() const
	{
      return PredXY;
   }

   void SetMaxRadius(const double dMax_m)
   {
      dMaxRadius_m=dMax_m;
   }

   double dGetMaxRadius() const
   {
      return dMaxRadius_m;
   }

};

//*******************************************************************************************

class Cst4_TWS_Plot : public Cst4Plot
{

	enum
	{
		MAX_TRACKS	= 16,
	};

	XYPos XY;
	double dMinDist_m;
	Cst4_TWS_Track* pTrack;
   bool bUsed;

	double dSqr(const double dV) const
	{
		return dV*dV;
	}

	double dGetDist_m(const XYPos& XY1) const
	{
		return sqrt(dSqr(XY.dx-XY1.dx)+dSqr(XY.dy-XY1.dy));
	}


public:

	Cst4_TWS_Plot()
	{
		Init();
	}

   void SetPlot(Cst4Plot& P)
   {
      Assign(P);
   }

	void SetXY(const XYPos& _XY)
	{
		XY=_XY;
	}

	XYPos GetXY() const
	{
		return XY;
	}

	void AddTrack(Cst4_TWS_Track* pNewTrack, const double dMaxRadius_m)
	{
		double dDist_m=dGetDist_m(pNewTrack->GetPredXY());
		if ((dDist_m<dMaxRadius_m)&&(dDist_m<dMinDist_m))
			{
			bool bValid=true;
			if (pTrack)
				{
				if (!pNewTrack->bSolidTrack())
					{
					bValid=false;
/*
					if (pTrack->bSolidTrack())
						{
						//Old track is solid, new track is not solid, but new track is closer
						if (dDist_m>dMinDist_m/2.0)
							bValid=false;	//ignore new track if distance is tot twice as close as previous track
						}
*/
					}
				}
			if (bValid)
				{
				dMinDist_m=dDist_m;
				pTrack=pNewTrack;
				}
			}
	}

	void Init()
	{
		pTrack=NULL;
		dMinDist_m=1e10;
      bUsed=false;
	}

	Cst4_TWS_Track* pGetTrack()
	{
		return pTrack;
	}

  	Cst4Plot GetPlot()
   {
      return *this;
   }

	double dGetMinDist_m() const
	{
		return dMinDist_m;
	}

   void SetUsed(const bool _bUsed)
   {
      bUsed=_bUsed;
   }

   bool bGetUsed() const
   {
      return bUsed;
   }

};


//*******************************************************************************************


class Cst4_TWS_Scan : public Transform
{

	JFile* pTestFile;

	Cst4_TWSSetupStruct Setup;
	JList<Cst4_TWS_Track> TWS;
	JList<Cst4_Radar_Track> Tracks;
	int nCurrentID;

	struct HistScan
	{
		int nSize;
		double dT_sec;
		XYPos* pXY;

		HistScan()
		{
			pXY=NULL;
		}

		~HistScan()
		{
			delete[] pXY;
		}

		void Assign(HistScan& T)
		{
			delete[] pXY;
			nSize=T.nSize;
			if (nSize>0)
				{
				pXY=new XYPos[nSize];
				memcpy(pXY,T.pXY,nSize*sizeof(XYPos));
				}
			else
				pXY=NULL;
			dT_sec=T.dT_sec;
		}

		HistScan& operator = (HistScan& T)
		{
			Assign(T);
			return *this;
		}

		HistScan(HistScan& T)
		{
			Assign(T);
		}

		void Init(const double _dT_sec, const int _nSize)
		{
			nSize=_nSize;
			delete[] pXY;
			pXY=new XYPos[nSize];
			dT_sec=_dT_sec;
		}

	}* pHist;

	int nMaxScans;
	int nScanCnt;
	int nScanIndex;

	void Correlate(Cst4_Radar_Scan& Scan);


public:

	Cst4_TWS_Scan(Cst4_TWSSetupStruct& _Setup, const int nFirstID)
	{
		Setup=_Setup;
		nScanCnt=0;
		nMaxScans=0;
		nScanIndex=0;
		pHist=NULL;
		nCurrentID=nFirstID;
		pTestFile=NULL;
		pTestFile=new JFile('O',JFile::ASCII_TYPE);

		if (pTestFile)
			pTestFile->Create("TWS Scan.txt");

	}

	~Cst4_TWS_Scan()
	{
		delete[] pHist;
		delete pTestFile;
	}

	void Assign(Cst4_TWS_Scan& T)
	{
		Setup=T.Setup;
		TWS=T.TWS;
		delete[] pHist;
		nMaxScans=T.nMaxScans;
		if (T.nMaxScans>0)
			{
			pHist=new HistScan[nMaxScans];
			for (int i=0; i<nScanCnt; i++)
				pHist[i]=T.pHist[i];
			}
		nScanCnt=T.nScanCnt;
		nScanIndex=T.nScanIndex;
		Tracks=T.Tracks;
	}

	Cst4_TWS_Scan& operator = (Cst4_TWS_Scan& T)
	{
		Assign(T);
		return *this;
	}

	Cst4_TWS_Scan(Cst4_TWS_Scan& T)
	{
		Assign(T);
	}

   void NewSetup(Cst4_TWSSetupStruct& _Setup)
   {
      Setup=_Setup;
   }

   void Update(Cst4_Radar_Scan& IScan);

   int nGetTrackCount()
   {
      return Tracks.nGetCount();
   }

   Cst4_Radar_Track& GetTrackMsg(const int n)
   {
      return *Tracks[n];
   }

   Cst4_Radar_Track* pGetTrackMsg(const int n)
   {
      return Tracks[n];
   }

};





#endif
