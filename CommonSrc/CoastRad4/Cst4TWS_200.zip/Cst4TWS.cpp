//---------------------------------------------------------------------------
#include "jpch.h"

#pragma hdrstop

#include "Cst4TWS.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)

void Cst4_TWSSetupStruct::Store(JIniFile* pIni, const String sHeading)
{
	pIni->Write(sHeading,"Alpha",dAlpha);
	pIni->Write("Moving Average Filter",nMAFilter);
	pIni->Write("Max Speed",nMaxSpeed_kts);
	pIni->Write("Abort after missed scans (acquisition)",nAcqMissedAbort);
	pIni->Write("Health Incr Percentage (acquisition)",nAcqIncPerc);
	pIni->Write("Health Incr Scans (acquisition)",nAcqIncScans);
	pIni->Write("Health Decr Percentage (acquisition)",nAcqDecPerc);
	pIni->Write("Health Decr Scans (acquisition)",nAcqDecScans);
	pIni->Write("Abort after missed scans (solid)",nSolidMissedAbort);
	pIni->Write("Health Incr Percentage (solid)",nSolidIncPerc);
	pIni->Write("Health Incr Scans (solid)",nSolidIncScans);
	pIni->Write("Health Decr Percentage (solid)",nSolidDecPerc);
	pIni->Write("Health Decr Scans (solid)",nSolidDecScans);
	pIni->Write("Use Scan Correlation",bCorr);
	pIni->Write("Scan Correlation Scans",nCorrScans);
	pIni->Write("Scan Correlation Percentage",nCorrPercent);
	pIni->Write("Min Solid Health",nMinHealth);
	pIni->Write("Max Solid Health",nMaxHealth);
	pIni->Write("Radar Error Range",dRaErr_m);
	pIni->Write("Radar Error Bearing",dBeErr_deg);
}

void Cst4_TWSSetupStruct::Read(JIniFile* pIni, const String sHeading)
{
	pIni->Read(sHeading,"Alpha",dAlpha,0.1);
	pIni->Read("Moving Average Filter",nMAFilter,10);
	pIni->Read("Max Speed",nMaxSpeed_kts,50);
	pIni->Read("Abort after missed scans (acquisition)",nAcqMissedAbort,3);
	pIni->Read("Health Incr Percentage (acquisition)",nAcqIncPerc,100);
	pIni->Read("Health Incr Scans (acquisition)",nAcqIncScans,1);
	pIni->Read("Health Decr Percentage (acquisition)",nAcqDecPerc,0);
	pIni->Read("Health Decr Scans (acquisition)",nAcqDecScans,1);
	pIni->Read("Abort after missed scans (solid)",nSolidMissedAbort,6);
	pIni->Read("Health Incr Percentage (solid)",nSolidIncPerc,100);
	pIni->Read("Health Incr Scans (solid)",nSolidIncScans,1);
	pIni->Read("Health Decr Percentage (solid)",nSolidDecPerc,0);
	pIni->Read("Health Decr Scans (solid)",nSolidDecScans,1);
	pIni->Read("Use Scan Correlation",bCorr,false);
	pIni->Read("Scan Correlation Scans",nCorrScans,5);
	pIni->Read("Scan Correlation Percentage",nCorrPercent,60);
	pIni->Read("Min Solid Health",nMinHealth,5);
	pIni->Read("Max Solid Health",nMaxHealth,15);
	pIni->Read("Radar Error Range",dRaErr_m,100.0);
	pIni->Read("Radar Error Bearing",dBeErr_deg,1.0);
}

bool Cst4_TWSSetupStruct::bInGate(const XYPos& Predict, const XYPos& Actual, const double dSpeedRadius_m, const double dMaxRadius_m, double& dDist_m)
{
	double dx_m=Actual.dx-Predict.dx;
	double dy_m=Actual.dy-Predict.dy;
	dDist_m=sqrt(dSqr(dx_m)+dSqr(dy_m));
	if (dDist_m>dMaxRadius_m)  //Check if targets are very far apart
		return false;	//targets too far apart
	if (dDist_m<=dSpeedRadius_m)
		return true;   //target within speed radius
	if (dSpeedRadius_m<1.0)
		return bInErrorGate(Predict,Actual); //Check Radar Errors only
	//Get intersection of line between Actual and Predicted on SpeedRadius circle
	double dTheta_rad=dATan_rad(dy_m,dx_m);
	double dx1_m=Predict.dx+dSpeedRadius_m*cos(dTheta_rad);	//x position of intersection
	double dy1_m=Predict.dy+dSpeedRadius_m*sin(dTheta_rad);	//y position of intersection
	return bInErrorGate(XYPos(dx1_m,dy1_m),Actual); 				//Check if edge position can fall in Radar Errors
}

void Cst4_TWS_Track::Next(const double dTime_sec, const XYPos& InXY)
{
   double dDeltaT_sec;
   if (dPrevTime_sec>=0.0)
      dDeltaT_sec=dTime_sec-dPrevTime_sec;
   if (dDeltaT_sec<0.001)
      dDeltaT_sec=0.001;
   else if (dDeltaT_sec>3600.0)
      dDeltaT_sec=3600.0;
   dPrevTime_sec=dTime_sec;
	if (nCount==0)
      {
		PredXY=InXY;
		StartXY=InXY;
		SmoothedXY=InXY;
      nCount++;
		}
	else
      {
		SmoothedXY.dx=PredXY.dx+pSetup->dAlpha*(InXY.dx-PredXY.dx);
		SmoothedXY.dy=PredXY.dy+pSetup->dAlpha*(InXY.dy-PredXY.dy);
		if (nCount==1)
         {
			VelXY.dx=(InXY.dx-StartXY.dx)/dDeltaT_sec;
			VelXY.dy=(InXY.dy-StartXY.dy)/dDeltaT_sec;
         nCount++;
			}
		else
			{
			VelXY.dx=VelXY.dx+(dBeta/dDeltaT_sec)*(InXY.dx-PredXY.dx);
			VelXY.dy=VelXY.dy+(dBeta/dDeltaT_sec)*(InXY.dy-PredXY.dy);
			}
		double dVel_mps=sqrt(dSqr(VelXY.dx)+dSqr(VelXY.dy));
		if (dVel_mps>dMaxVel_mps)
			{
			double dFact=dMaxVel_mps/dVel_mps;
			VelXY.dx*=dFact;
			VelXY.dy*=dFact;
			}
		PredXY.dx=SmoothedXY.dx+dDeltaT_sec*VelXY.dx;
		PredXY.dy=SmoothedXY.dy+dDeltaT_sec*VelXY.dy;
		}
	PredPol=pTrans->XY2Pol(PredXY);
	bSmoothValid=true;
}

void Cst4_TWS_Track::NextPos(const double dTime_sec, const XYPos& XY, int& nCurrentID)
{
	if (pTFil)
		{
		String s;
		s.printf(L"X: %6.0f  Y:%6.0f  Health: %2d",XY.dx,XY.dy,nHealth);
		if (bSolid)
			pTFil->TextLine("SOLID "+s);
		else
			pTFil->TextLine("ACQ "+s);
		}
	SolidHist.AddScan();	//Always update SolidHist (to build up history)
	if (bSolid)
		{
		SolidHist.UpdateHealth(nHealth);
		}
	else
		{
		//Acquisition mode
		AcqHist.AddScan();	//AcqHist is only used until solid track
		AcqHist.UpdateHealth(nHealth);
		if (nHealth>=pSetup->nMinHealth)
			{
			bSolid=true;	//never returns to acq mode
			nTrackID=nCurrentID++;	//Assign ID only to solid track - then incr ID
			}
		}

	if (pTFil)
		{
		pTFil->TextLine("    Acq: "+AcqHist.sStatus()+"  Solid: "+SolidHist.sStatus());
		String s;
		s.printf(L"X: %6.0f  Y:%6.0f  Health: %2d",XY.dx,XY.dy,nHealth);
		if (bSolid)
			pTFil->TextLine("    SOLID "+s);
		else
			pTFil->TextLine("    ACQ   "+s);
		pTFil->TextLine("");
		}

	Next(dTime_sec,InXY);
}

void Cst4_TWS_Track::NextPos(const double dTime_sec)
{

	if (pTFil)
		{
		String s;
		s.printf(L"*** Memory Track  H: %2d",nHealth);
		pTFil->TextLine(s);
		pTFil->TextLine("    Acq: "+AcqHist.sStatus()+"  Solid: "+SolidHist.sStatus());
		}


	SolidHist.SkipScan();	//Always update SolidHist
	if (bSolid)
		SolidHist.UpdateHealth(nHealth);
	else
		{
		//Acquisition mode
		AcqHist.SkipScan();	//AcqHist is only used until solid track
		AcqHist.UpdateHealth(nHealth);
		}
	if (nCount>0)
		Next(dTime_sec,PredXY);
	else
		{
		SmoothedXY=XYPos(0.0,0.0);
		bSmoothValid=false;
		}

	if (pTFil)
		{
		pTFil->TextLine("    Acq: "+AcqHist.sStatus()+"  Solid: "+SolidHist.sStatus());
		pTFil->TextLine("");
		}


}

double Cst4_TWS_Track::dMAFilter_sec(const XYPos& XY, const XYPos& Vel, const double dT_sec, XYPos& XY_Filt, XYPos& Vel_Filt)
{
	double dT1_sec;
	if (nMACnt<pSetup->nMAFilter)
		{
		if (nMACnt==0)
			dT1_sec=dT_sec;
		else
			dT1_sec=pdMATime_sec[0];
		++nMACnt;
		}
	else
		{
		MATot.dx-=pMABuf[nMAIndex].dx;
		MATot.dy-=pMABuf[nMAIndex].dy;
      MAVelTot.dx-=pMAVel[nMAIndex].dx;
      MAVelTot.dy-=pMAVel[nMAIndex].dy;
      dT1_sec=pdMATime_sec[nMAIndex];
      }
   pMABuf[nMAIndex]=XY;
   pdMATime_sec[nMAIndex]=dT_sec;
   MATot.dx+=XY.dx;
   MATot.dy+=XY.dy;
   MAVelTot.dx+=Vel.dx;
   MAVelTot.dy+=Vel.dy;
	if (nMAIndex<pSetup->nMAFilter-1)
		++nMAIndex;
	else
		nMAIndex=0;
   XY_Filt=XYPos(MATot.dx/nMACnt,MATot.dy/nMACnt);
   Vel_Filt=XYPos(MAVelTot.dx/nMACnt,MAVelTot.dy/nMACnt);
   double dTrackTime_sec=(dT_sec+dT1_sec)/2.0;
   return dTrackTime_sec;
}

void Cst4_TWS_Track::CalcTrack(int& nCurrentID)
{
	if (InXY.bValid())
      NextPos(dScanTime_sec,InXY,nCurrentID);
   else
      NextPos(dScanTime_sec);//Memory track
   XYPos MA_XY,MA_Vel;
   double dT_sec=dMAFilter_sec(SmoothedXY,VelXY,dScanTime_sec,MA_XY,MA_Vel);
   MA_Vel=VelXY;    //Do not use MA filtered Vel
   LatLong LL=pTrans->XY2LL(MA_XY);
   double dSpeed_kts=sqrt(dSqr(MA_Vel.dx)+dSqr(MA_Vel.dy))*2.0;
   double dCourse_deg;
   if (fabs(MA_Vel.dy)>1e-10)
      dCourse_deg=atan2(MA_Vel.dx,MA_Vel.dy)*180.0/M_PI;
	else
		if (MA_Vel.dx>0.0)
			dCourse_deg=90.0;
		else
			dCourse_deg=270.0;
	pTrackMsg->Set(JTime(dT_sec),nTrackID,LL,dSpeed_kts,dCourse_deg,nHealth,wSource);
}


void Cst4_TWS_Scan::Correlate(Cst4_Radar_Scan& Scan)
{
	int nPlotCnt=Scan.nGetPlotCnt();
	if (nPlotCnt>0)
		{
		HistScan CS;	//Current Scan
		CS.Init(Scan.dTime_sec(),nPlotCnt);
		int* pnCnt=new int[nPlotCnt];
		for (int nP=0; nP<nPlotCnt; nP++)
			{
			Polar Pol(Scan.pPlot(nP)->dRa_m(),Scan.pPlot(nP)->dBe_deg());
			CS.pXY[nP]=XYPos(Pol2XY(Pol));
			pnCnt[nP]=0;
			}
		if (nScanCnt>0)
			{
			for (int nP=0; nP<nPlotCnt; nP++)
				{
				double dErrRadius_m=Setup.dCalcErrRadius_m(Scan.pPlot(nP)->dRa_m());
				for (int nS=0; nS<nScanCnt; nS++)
					{
					if (nS!=nScanIndex)
						{
						double dSpeedRadius_m=Setup.dCalcSpeedRadius_m(Setup.nMaxHealth,CS.dT_sec-pHist[nS].dT_sec);
						for (int i=0; i<pHist[nS].nSize; i++)
							{
							if (Setup.bInGate(pHist[nS].pXY[i],CS.pXY[nP],dSpeedRadius_m,dSpeedRadius_m+dErrRadius_m))
								{
								++pnCnt[nP];
								i=pHist[nS].nSize;	//stop loop
                        }
							}
						}
					}
				}
			}
		pHist[nScanIndex++]=CS;
		if (nScanIndex>=nMaxScans)
			nScanIndex=0;
		if (nScanCnt<nMaxScans)
			++nScanCnt;
		int nScanCnt=(Setup.nCorrPercent*Setup.nCorrScans)/100.0+0.5;
		for (int i=nPlotCnt-1; i>=0; i++)
			{
			if (pnCnt[i]<nScanCnt)
				Scan.InvalidatePlot(i);
			}
		delete[] pnCnt;
		}
}

void Cst4_TWS_Scan::Update(Cst4_Radar_Scan& IScan)
{
	Cst4_Radar_Scan Scan;
	Scan=IScan;
	if (nScanCnt==0)
		{
		SetTransformType(Transform::FLAT_TRANS);
		SetLLRef(Scan.GetRadarLL());
		SetRadarPos(Scan.GetRadarLL());
		}
	++nScanCnt;
	if (Setup.bCorr)
		Correlate(Scan);
	int nScanPlotNum=Scan.nGetPlotCnt();

   double dT_sec=Scan.dTime_sec();
   TWS.GoFirst();
   while(!TWS.bLast())
      TWS.pNext()->InitScan(dT_sec);
   Cst4_TWS_Plot* pPlot=NULL;
	Cst4_TWS_Track* pT;
	String s;
	if (nScanPlotNum>0)
		{
		pPlot=new Cst4_TWS_Plot[nScanPlotNum];
		XYPos XY;

		for (int i=0; i<nScanPlotNum; i++)
			{
			pPlot[i].SetPlot(*Scan.pPlot(i));
			XY=Pol2XY(Polar(Scan.pPlot(i)->dRa_m(),Scan.pPlot(i)->dBe_deg()));
//			if (pTestFile)
//				pTestFile->TextLine(s.sprintf(L"Plot %3d: %6.0f  %6.0f",i,XY.dx,XY.dy));
			pPlot[i].SetXY(XY);
   		TWS.GoFirst();
   		while(!TWS.bLast())
         	{
      		pT=TWS.pNext();
            pPlot[i].AddTrack(pT,pT->dGetMaxRadius());
            }
         if (pPlot[i].pGetTrack())
            pPlot[i].SetUsed(pPlot[i].pGetTrack()->bAddPlot(pPlot[i].GetXY()));
         }
		}
	//Calculate

	if (nScanPlotNum==0)
		nScanPlotNum=0;

	TWS.GoFirst();
	while(!TWS.bLast())
		TWS.pNext()->CalcTrack(nCurrentID);
	int nUnUsed=0;
	for (int nP=0; nP<nScanPlotNum; nP++)
		{
		//Initiate tracks on unused plots
		if (!pPlot[nP].bGetUsed())
			{
			Cst4_TWS_Track* pNT;
			pNT=new Cst4_TWS_Track(&Setup,this,Scan.pPlot(nP),Scan.dTime_sec(),Scan.wSource());
			TWS.nAdd(pNT);
			++nUnUsed;
			}
		}
	delete[] pPlot;
		pTestFile->TextLine(s.sprintf(L"    TWS Count %3d",TWS.nGetCount()));
	//Delete aborted tracks
	TWS.GoFirst();
	int nAborted=0;
	while(!TWS.bLast())
		{
		if (TWS.pNext()->bAborted())
			{
			TWS.GoPrev();
			TWS.Delete();
			++nAborted;
			}
		}

	if (pTestFile)
		{
		pTestFile->TextLine(s.sprintf(L"****  Scan %3d (Plots: %3d, UnUsed: %3d)",nScanCnt,nScanPlotNum,nUnUsed));
		pTestFile->TextLine(s.sprintf(L"    TWS Count %3d, Aborted: %3d",TWS.nGetCount(),nAborted));
		}

	//Create current track list
	Tracks.Clear();
   TWS.GoFirst();
   while(!TWS.bLast())
      {
      pT=TWS.pNext();
		if (pT->bSolidTrack())
			Tracks.nAdd(new Cst4_Radar_Track(pT->GetTrackMsg()));
		}
	Tracks.Pack();
}

