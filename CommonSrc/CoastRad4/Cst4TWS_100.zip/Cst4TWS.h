//---------------------------------------------------------------------------

#ifndef Cst4TWSH
#define Cst4TWSH
//---------------------------------------------------------------------------

#include "Cst4Messages.h"
#include "JIniFile.h"
#include "JFile.h"

struct Cst4_TWSSetupStruct
{
   double dAlpha;
   int nMaxSpeed_kts;
   int nAbort;
   int nAcqAbort;
   double dMaxExpand;
   int nMinHealth;
   int nMaxHealth;
   Polar RadarError;
   int nMAFilter;

   Cst4_TWSSetupStruct()
   {
      dAlpha=0.1;
      nMaxSpeed_kts=50;
      nAbort=6;
      nAcqAbort=3;
      dMaxExpand=5.0;
      nMinHealth=15;
      nMaxHealth=30;
      RadarError.dRa=300.0;
      RadarError.dBe=1.5;
      nMAFilter=20;
   }

   void Assign(Cst4_TWSSetupStruct& T)
   {
      dAlpha=T.dAlpha;
      nMaxSpeed_kts=T.nMaxSpeed_kts;
      nAbort=T.nAbort;
      nAcqAbort=T.nAcqAbort;
      dMaxExpand=T.dMaxExpand;
      nMinHealth=T.nMinHealth;
      nMaxHealth=T.nMaxHealth;
      RadarError=T.RadarError;
      nMAFilter=T.nMAFilter;
   }

   Cst4_TWSSetupStruct& operator = (Cst4_TWSSetupStruct& T)
   {
      Assign(T);
      return *this;
   }

   void Store(JIniFile* pIni, const String sHeading);
   void Read(JIniFile* pIni, const String sHeading);

};


class Cst4_TWS_Track
{

   JFile* pTestFil;

   Cst4_TWSSetupStruct* pSetup;
   Transform* pTrans;

   WORD wSourceID;
   int nTrackID;
   Cst4_Radar_Track* pTrackMsg;

	double dBeta;
   double dMaxVel_mps;

	XYPos StartXY,PredXY,VelXY,SmoothedXY;
   Polar PredPol;

   double dMinRa_m,dMaxRa_m,dMinBe_deg,dMaxBe_deg;

   double dScanTime_sec;
   double dMinDist_m;
   int nPlotNum;
   Polar InPol;

	int nSkipped;
   int nCount;
   int nValid;
   double dPrevTime_sec;
   int nHealth;
   bool bSolid;
   bool bSmoothValid;

   bool bForceAbort;

   XYPos* pMABuf;
   double* pdMATime_sec;
   XYPos* pMAVel;
   int nMACnt;
   int nMAIndex;
   XYPos MATot;
   XYPos MAVelTot;

	void Next(const double dTime_sec, const XYPos& InXY);
	void NextPos(const double dTime_sec, const XYPos& InXY);
	void NextPos(const double dTime_sec);

   double dSqr(const double dV) const
   {
      return dV*dV;
   }

   void CalcNextWindow()
   {
      double dExpandFact;
      if (nHealth<=pSetup->nMinHealth)
         dExpandFact=pSetup->dMaxExpand;
      else if (nHealth>=pSetup->nMaxHealth)
         dExpandFact=1.0;
      else
         {
         dExpandFact=((nHealth-pSetup->nMinHealth)*1.0)/(pSetup->nMaxHealth-pSetup->nMinHealth);
         dExpandFact=(1.0-dExpandFact)*(pSetup->dMaxExpand-1.0)+1.0;
         }
      dMaxRa_m=pSetup->RadarError.dRa*dExpandFact+PredPol.dRa;
      dMinRa_m=PredPol.dRa-pSetup->RadarError.dRa*dExpandFact;
      dMaxBe_deg=pSetup->RadarError.dBe*dExpandFact+PredPol.dBe;
      if (dMaxBe_deg>=360.0)
         dMaxBe_deg-=360.0;
      else if (dMaxBe_deg<0.0)
         dMaxBe_deg+=360.0;
      dMinBe_deg=PredPol.dBe-pSetup->RadarError.dBe*dExpandFact;
      if (dMinBe_deg>=360.0)
         dMinBe_deg-=360.0;
      else if (dMinBe_deg<0.0)
         dMinBe_deg+=360.0;
   }

   double dCalcDist_m(const Polar& Pol)
   {
      if ((Pol.dRa>=dMinRa_m)&&(Pol.dRa<=dMaxRa_m))
         {
         bool bValid;
         if (dMaxBe_deg>dMinBe_deg)
            bValid=(Pol.dBe>=dMinBe_deg)&&(Pol.dBe<=dMaxBe_deg);
         else
            bValid=(Pol.dBe>=dMaxBe_deg)||(Pol.dBe<=dMinBe_deg);
         if (bValid)
            {
            XYPos XY=pTrans->Pol2XY(Pol);
            return sqrt(dSqr(XY.dx-PredXY.dx)+dSqr(XY.dy-PredXY.dy));
            }
         }
      return 1e20;
   }

   double dMAFilter_sec(const XYPos& XY, const XYPos& Vel, const double dT_sec, XYPos& XY_Filt, XYPos& Vel_Filt);


public:

   Cst4_TWS_Track(Cst4_TWSSetupStruct* _pSetup, Transform* _pTrans, Cst4Plot* pPlot, const double dT_sec, const WORD _wSourceID, const int _nTrackID)
   {
      memset(this,0,sizeof(Cst4_TWS_Track));
      pMABuf=NULL;
      pdMATime_sec=NULL;
      pMAVel=NULL;
      pSetup=_pSetup;
      pTrans=_pTrans;
      pTrackMsg=new Cst4_Radar_Track;
      ResetFilters();
      Polar Pol(pPlot->dRa_m(),pPlot->dBe_deg());
      PredPol=Pol;
      StartXY=pTrans->Pol2XY(Pol);
      PredXY=StartXY;
      dPrevTime_sec=dT_sec;
      wSourceID=_wSourceID;
      nTrackID=_nTrackID;
   	dBeta=2.0*(2.0-pSetup->dAlpha)-4.0*sqrt(1.0-pSetup->dAlpha);
      dMaxVel_mps=pSetup->nMaxSpeed_kts/2.0;
      VelXY=XYPos(0.0,0.0);
      dPrevTime_sec=-1000.0;
      nCount=0;
      nSkipped=0;
      bSolid=false;
      nHealth=0;
      bSmoothValid=false;

      pTestFil=NULL;
//      pTestFil=new JFile('I',JFile::ASCII_TYPE);

      if (pTestFil)
         {
         String s;
         s.printf(L"TWS Test (Src %04X)  Tr %05d.txt",wSourceID,nTrackID);
         pTestFil->Create(s);
         }



   }

   ~Cst4_TWS_Track()
   {
      delete[] pMAVel;
      delete[] pdMATime_sec;
      delete[] pMABuf;
      delete pTrackMsg;
      delete pTestFil;
   }

   void Assign(Cst4_TWS_Track& M)
   {


//      Setup=M.Setup;
   }

   Cst4_TWS_Track& operator = (Cst4_TWS_Track& M)
   {
      Assign(M);
      return *this;
   }

   Cst4_TWS_Track(Cst4_TWS_Track& M)
   {
      Assign(M);
   }

   void ResetFilters()
   {
      VelXY=XYPos(0.0,0.0);
      delete[] pdMATime_sec;
      delete[] pMABuf;
      delete[] pMAVel;
      pMABuf=new XYPos[pSetup->nMAFilter];
      pdMATime_sec=new double[pSetup->nMAFilter];
      pMAVel=new XYPos[pSetup->nMAFilter];
      MATot=XYPos(0.0,0.0);
      MAVelTot=XYPos(0.0,0.0);
      nMACnt=0;
      nMAIndex=0;
   }


   void InitScan(const double dT_sec)
   {
      dScanTime_sec=dT_sec;
      dMinDist_m=1e10;
      nPlotNum=-1;
      InPol.Invalidate();
      CalcNextWindow();
   }

   void AddPlot(const Cst4Plot* pPlot, const int n)
   {
      Polar Pol(pPlot->dRa_m(),pPlot->dBe_deg());
      double dDist_m=dCalcDist_m(Pol);
      if (dDist_m<dMinDist_m)
         {
         dMinDist_m=dDist_m;
         nPlotNum=n;
         InPol=Pol;
         }
   }

   void AddPlot(const Cst4Plot& Plot, const int n)
   {
      AddPlot(&Plot,n);
   }

   int nUsedPlotNum() const
   {
      return nPlotNum;
   }

   void CalcTrack();

   Cst4_Radar_Track& GetTrackMsg()
   {
      return *pTrackMsg;
   }

   Cst4_Radar_Track* pGetTrackMsg()
   {
      return pTrackMsg;
   }

   bool bAborted() const
   {
      if (bSolid)
         return (nSkipped>=pSetup->nAbort)||(bForceAbort);
      else
         return (nSkipped>=pSetup->nAcqAbort)||(bForceAbort);
   }

   bool bSolidTrack() const
   {
      return bSolid;
   }

   bool bSameSource(const WORD wNewID) const
   {
      return (wNewID==wSourceID);
   }

   int nGetHealth() const
   {
      return nHealth; 
   }

   int nGetID() const
   {
      return nTrackID;
   }

};

//*******************************************************************************************

class Cst4_TWS_Scan : public Transform
{

   Cst4_TWSSetupStruct Setup;
   JList<Cst4_TWS_Track> TWS;
   int nCurrentID;
   WORD wPrevSource;
   JList<Cst4_Radar_Track> Tracks;
   int nScanCnt;

public:

   Cst4_TWS_Scan(Cst4_TWSSetupStruct& _Setup)
   {
      Setup=_Setup;
      nCurrentID=0;
      nScanCnt=0;
      wPrevSource=0xFFFF;
   }

   ~Cst4_TWS_Scan()
   {
   }

   void Assign(Cst4_TWS_Scan& T)
   {
      Setup=T.Setup;
      TWS=T.TWS;
      nCurrentID=T.nCurrentID;
      nScanCnt=T.nScanCnt;
      wPrevSource=T.wPrevSource;
      Tracks=T.Tracks;
   }

   Cst4_TWS_Scan& operator = (Cst4_TWS_Scan& T)
   {
      Assign(T);
      return *this;
   }

   Cst4_TWS_Scan(Cst4_TWS_Scan& T)
   {
      Assign(T);
   }

   void NewSetup(Cst4_TWSSetupStruct& _Setup)
   {
      Setup=_Setup;
   }

   void Update(Cst4_Radar_Scan& Scan);

   int nGetTrackCount()
   {
      return Tracks.nGetCount();
   }

   Cst4_Radar_Track& GetTrackMsg(const int n)
   {
      return *Tracks[n];
   }

   Cst4_Radar_Track* pGetTrackMsg(const int n)
   {
      return Tracks[n];
   }

};





#endif
