//---------------------------------------------------------------------------
#include "jpch.h"

#pragma hdrstop

#include "Cst4TWS.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)

void Cst4_TWSSetupStruct::Store(JIniFile* pIni, const String sHeading)
{
   pIni->Write(sHeading,L"Alpha",dAlpha);
   pIni->Write(L"Max Speed",nMaxSpeed_kts);
   pIni->Write(L"Abort after missed scans (solid)",nAbort);
   pIni->Write(L"Abort after missed scans (acquisition)",nAcqAbort);
   pIni->Write(L"Max Expansion",dMaxExpand);
   pIni->Write(L"Min Health",nMinHealth);
   pIni->Write(L"Max Health",nMaxHealth);
   pIni->Write(L"Radar Error Range",RadarError.dRa);
   pIni->Write(L"Radar Error Bearing",RadarError.dBe);
   pIni->Write(L"Moving Average Filter",nMAFilter);
}

void Cst4_TWSSetupStruct::Read(JIniFile* pIni, const String sHeading)
{
   pIni->Read(sHeading,L"Alpha",dAlpha,0.1);
   pIni->Read(L"Max Speed",nMaxSpeed_kts,50);
   pIni->Read(L"Abort after missed scans (solid)",nAbort,6);
   pIni->Read(L"Abort after missed scans (acquisition)",nAcqAbort,3);
   pIni->Read(L"Max Expansion",dMaxExpand,5.0);
   pIni->Read(L"Min Health",nMinHealth,3);
   pIni->Read(L"Max Health",nMaxHealth,10);
   pIni->Read(L"Radar Error Range",RadarError.dRa,300.0);
   pIni->Read(L"Radar Error Bearing",RadarError.dBe,1.5);
   pIni->Read(L"Moving Average Filter",nMAFilter,10);
}


void Cst4_TWS_Track::Next(const double dTime_sec, const XYPos& InXY)
{
   double dDeltaT_sec;
   if (dPrevTime_sec>=0.0)
      dDeltaT_sec=dTime_sec-dPrevTime_sec;
   if (dDeltaT_sec<0.001)
      dDeltaT_sec=0.001;
   else if (dDeltaT_sec>3600.0)
      dDeltaT_sec=3600.0;
   dPrevTime_sec=dTime_sec;
	if (nCount==0)
      {
		PredXY=InXY;
		StartXY=InXY;
		SmoothedXY=InXY;
      nCount++;
		}
	else
      {
		SmoothedXY.dx=PredXY.dx+pSetup->dAlpha*(InXY.dx-PredXY.dx);
		SmoothedXY.dy=PredXY.dy+pSetup->dAlpha*(InXY.dy-PredXY.dy);
		if (nCount==1)
         {
			VelXY.dx=(InXY.dx-StartXY.dx)/dDeltaT_sec;
			VelXY.dy=(InXY.dy-StartXY.dy)/dDeltaT_sec;
         nCount++;
			}
		else
         {
			VelXY.dx=VelXY.dx+(dBeta/dDeltaT_sec)*(InXY.dx-PredXY.dx);
			VelXY.dy=VelXY.dy+(dBeta/dDeltaT_sec)*(InXY.dy-PredXY.dy);
			}
      double dVel_mps=sqrt(dSqr(VelXY.dx)+dSqr(VelXY.dy));
      if (dVel_mps>dMaxVel_mps)
         {
         double dFact=dMaxVel_mps/dVel_mps;
         VelXY.dx*=dFact;
         VelXY.dy*=dFact;
         }
		PredXY.dx=SmoothedXY.dx+dDeltaT_sec*VelXY.dx;
		PredXY.dy=SmoothedXY.dy+dDeltaT_sec*VelXY.dy;
		}
   PredPol=pTrans->XY2Pol(PredXY);
   bSmoothValid=true;
}

void Cst4_TWS_Track::NextPos(const double dTime_sec, const XYPos& InXY)
{
	nSkipped=0;
   if (nHealth<pSetup->nMaxHealth) ++nHealth;
   if (nHealth>=pSetup->nMinHealth) bSolid=true;
   Next(dTime_sec,InXY);
}



void Cst4_TWS_Track::NextPos(const double dTime_sec)
{
	++nSkipped;
   if (nHealth>0) --nHealth;
   if (nCount>0)
   	Next(dTime_sec,PredXY);
   else
      {
      SmoothedXY=XYPos(0.0,0.0);
      bSmoothValid=false;
      }
}

double Cst4_TWS_Track::dMAFilter_sec(const XYPos& XY, const XYPos& Vel, const double dT_sec, XYPos& XY_Filt, XYPos& Vel_Filt)
{
   double dT1_sec;
	if (nMACnt<pSetup->nMAFilter)
      {
      if (nMACnt==0)
         dT1_sec=dT_sec;
      else
         dT1_sec=pdMATime_sec[0];
		++nMACnt;
      }
	else
      {
      MATot.dx-=pMABuf[nMAIndex].dx;
      MATot.dy-=pMABuf[nMAIndex].dy;
      MAVelTot.dx-=pMAVel[nMAIndex].dx;
      MAVelTot.dy-=pMAVel[nMAIndex].dy;
      dT1_sec=pdMATime_sec[nMAIndex];
      }
   pMABuf[nMAIndex]=XY;
   pdMATime_sec[nMAIndex]=dT_sec;
   MATot.dx+=XY.dx;
   MATot.dy+=XY.dy;
   MAVelTot.dx+=Vel.dx;
   MAVelTot.dy+=Vel.dy;
	if (nMAIndex<pSetup->nMAFilter-1)
		++nMAIndex;
	else
		nMAIndex=0;
   XY_Filt=XYPos(MATot.dx/nMACnt,MATot.dy/nMACnt);
   Vel_Filt=XYPos(MAVelTot.dx/nMACnt,MAVelTot.dy/nMACnt);
   double dTrackTime_sec=(dT_sec+dT1_sec)/2.0;
   return dTrackTime_sec;
}


void Cst4_TWS_Track::CalcTrack()
{

   if (pTestFil)
      {
      String s;
      if (nPlotNum>=0)
         s.printf(L"%5d  %6.0f m  %7.3f deg  %2d",nPlotNum,InPol.dRa,InPol.dBe,nHealth);
      else
         s.printf(L"Memory Track  %2d",nHealth);
      pTestFil->TextLine(s);

      }
	if (nPlotNum>=0)
      NextPos(dScanTime_sec,pTrans->Pol2XY(InPol));
   else
      NextPos(dScanTime_sec);//Memory track
   XYPos MA_XY,MA_Vel;
   double dT_sec=dMAFilter_sec(SmoothedXY,VelXY,dScanTime_sec,MA_XY,MA_Vel);
   MA_Vel=VelXY;    //Do not use MA filtered Vel
   LatLong LL=pTrans->XY2LL(MA_XY);
   double dSpeed_kts=sqrt(dSqr(MA_Vel.dx)+dSqr(MA_Vel.dy))*2.0;
   double dCourse_deg;
   if (fabs(MA_Vel.dy)>1e-10)
      dCourse_deg=atan2(MA_Vel.dx,MA_Vel.dy)*180.0/M_PI;
   else
      if (MA_Vel.dx>0.0)
         dCourse_deg=90.0;
      else
         dCourse_deg=270.0;
	pTrackMsg->Set(JTime(dT_sec),nTrackID,LL,dSpeed_kts,dCourse_deg,nHealth,wSourceID);
}


void Cst4_TWS_Scan::Update(Cst4_Radar_Scan& Scan)
{
   ++nScanCnt;
   WORD wSource=Scan.wSource();
   if (wSource!=wPrevSource)
      {
      SetLLRef(Scan.GetRadarLL());
      SetRadarPos(Scan.GetRadarLL());
      wPrevSource=wSource;
      }
   Cst4_TWS_Track* pT;
   TWS.GoFirst();
   while(!TWS.bLast())
      {
      pT=TWS.pNext();
      if (pT->bSameSource(wSource))
         {
         pT->InitScan(Scan.dTime_sec());
			for (int nP=0; nP<Scan.nGetPlotCnt(); nP++)
            {
            if (!Scan.pPlot(nP)->bUsed())
               pT->AddPlot(Scan.pPlot(nP),nP);
				}
         int nPlotUsed=pT->nUsedPlotNum();
         if (nPlotUsed>=0)
            Scan.pPlot(nPlotUsed)->SetUsed();
         pT->CalcTrack();
			}
      }
   for (int nP=0; nP<Scan.nGetPlotCnt(); nP++)
      {
      if (!Scan.pPlot(nP)->bUsed())
         TWS.nAdd(new Cst4_TWS_Track(&Setup,this,Scan.pPlot(nP),Scan.dTime_sec(),Scan.wSource(),++nCurrentID));
      }
   TWS.GoFirst();
   while(!TWS.bLast())
      {
      if (TWS.pNext()->bAborted())
         {
         TWS.GoPrev();
         TWS.Delete();
         }
      }
   Tracks.Clear();
   TWS.GoFirst();
   while(!TWS.bLast())
      {
      pT=TWS.pNext();
      if (pT->bSolidTrack() && !pT->bAborted() && pT->nGetHealth()>=Setup.nMinHealth)
         Tracks.nAdd(new Cst4_Radar_Track(pT->GetTrackMsg()));
      }
   Tracks.Pack();
}

