//---------------------------------------------------------------------------

#ifndef SurfDevBrowseDlgH
#define SurfDevBrowseDlgH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.Buttons.hpp>
#include <CheckLst.hpp>
#include <Vcl.ExtCtrls.hpp>

#include "NumEdit.h"
#include "SurfDefs.h"

//---------------------------------------------------------------------------
class TSurfDevBrowseForm : public TForm
{
__published:	// IDE-managed Components
   TBevel *Bevel1;
   TGroupBox *GroupBox1;
   TRadioButton *NEMASRad;
   TRadioButton *ITBRad;
   TRadioButton *FSGRad;
   TLabel *Label1;
   TLabel *Label2;
   TEdit *ExtEd;
   JNumEdit *IDEd;
   TLabel *Label3;
   TBitBtn *OKBut;
   TBitBtn *CancelBut;
   TListBox *DevLB;
   TRadioButton *T209Rad;
   TRadioButton *CstRad;
   void __fastcall FormCreate(TObject *Sender);
   void __fastcall FormShow(TObject *Sender);
   void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
   void __fastcall FormDestroy(TObject *Sender);
   void __fastcall NEMASRadClick(TObject *Sender);
   void __fastcall ITBRadClick(TObject *Sender);
   void __fastcall FSGRadClick(TObject *Sender);
   void __fastcall DevLBClick(TObject *Sender);
   void __fastcall T209RadClick(TObject *Sender);
   void __fastcall CstRadClick(TObject *Sender);
   void __fastcall DevLBDblClick(TObject *Sender);
private:	// User declarations

   SurfPredefDevices Dev;
   SURF_PREDEF_LOCATION Location;

public:		// User declarations
   __fastcall TSurfDevBrowseForm(TComponent* Owner);

   int nID;
   String sDescr;
   String sExt;

   bool bImportCSV;

};
//---------------------------------------------------------------------------
extern PACKAGE TSurfDevBrowseForm *SurfDevBrowseForm;
//---------------------------------------------------------------------------
#endif
