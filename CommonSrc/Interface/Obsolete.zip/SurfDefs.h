/********** CONFIGURATION HEADER **************************************
MODULE TITLE	Surface Plot Data Definitions
COMPILER       Borland C++ Builder 6
PROCESSOR      Pentium IV
OS					MS Windows XP
PROGRAMMER     Johan Theron
CHANGE HISTORY
   Version 1.0.0  : Initial Version JGT 06/04/2004

   Version 2.0.0  : JGT 09/07/2009
                     1. Implement Extended Information as add-on to SurfPlotDataDef class


************************************************************************/

//---------------------------------------------------------------------------
#ifndef SurfDefsH
#define SurfDefsH
//---------------------------------------------------------------------------

#include "JTransform.h"
#include "JList.h" 
#include "CoastDataDef.h"

#pragma option push -bi-    //Do not treat enums as ints

enum
{
	DEVICE_2_SURF_PORT         = 8,
	SURF_2_DEVICE_PORT         = 9,
	LOCAL_2_LOCAL_PORT         = 10,
	COASTHUB_DATASERVER_PORT   = 11,
	COASTHUB_TIMESERVER_PORT   = 12,
	INS_SERVER_PORT            = 13,
	SURF_TIMESERVER_PORT       = 14,
	BLAH_SLAVE_PORT            = 15,
	GPS_SERVER_PORT            = 16,
	SURF_UDP_PORT            	= 1712,
};

enum SURF_REQUEST
{
	SURF_NO_REQUEST      = 0,
	SURF_TIME_REQUEST    = 1,
	SURF_INS_REQUEST     = 2,
};


//Definitions for the extra parameter locations (SetExtra/GetExtra)
enum
{

	EXTRA_INS_HEADING    = 0,
	EXTRA_INS_ROLL       = 1,
	EXTRA_INS_PITCH      = 2,
	EXTRA_INS_ROLL_ACCEL = 3,

	EXTRA_NA10_RCS       = 0,

	EXTRA_ANGLES_RA      = 0,

	EXTRA_RSCAN_X        = 0,
	EXTRA_RSCAN_Y        = 1,
	EXTRA_RSCAN_SOURCE   = 2,

	EXTRA_SEARANGE_BE    = 0,

	EXTRA_AIS_CARGO      = 1,
	EXTRA_AIS_IMO        = 2,

	EXTRA_SOURCE_ERR     = 3,

};


enum
{
	SRC_ERR_NONE         = 0,
	SRC_ERR_GPSTIME      = 1,
	SRC_ERR_MRR_ANGLES   = 2,
};

//Plot Type Definitions
enum SURF_PLOT_TYPE
{
	PLOT_TYPE_PLOT       = 0,
	PLOT_TYPE_PSR_AIR    = 1,
	PLOT_TYPE_SEC        = 2,
	PLOT_TYPE_ASSOC      = 3,
	PLOT_TYPE_AIS        = 4,
	PLOT_TYPE_SINGLE     = 5,
	PLOT_TYPE_ANGLES     = 6,
	PLOT_TYPE_CANCEL     = 7,
	PLOT_TYPE_OWNPOS     = 8,
	PLOT_TYPE_INS        = 10,
	PLOT_TYPE_PSR_3D     = 9,
	PLOT_TYPE_PSR_CMS    = 11,
	PLOT_TYPE_PSR_MEM    = 12,
	PLOT_TYPE_PSR_SURF   = 13,
	PLOT_TYPE_PSR_TWS    = 14,
	PLOT_TYPE_PSR_SPLASH = 15,

};

enum SURF_PLOT_STATUS
{
	PLOT_INVALID         = 0x00000000,
	PLOT_LL_VALID        = 0x00000001,
	PLOT_HEIGHT_VALID    = 0x00000002,
	PLOT_TIME_VALID      = 0x00000004,
	PLOT_ID_VALID        = 0x00000008,
	PLOT_SP_CO_VALID     = 0x00000010,
	PLOT_ANGLES_VALID    = 0x00000020,
	PLOT_NAME_VALID      = 0x00000040,
	PLOT_CALLSIGN_VALID  = 0x00000080,

	PLOT_EXTRA0_VALID    = 0x00000100,
	PLOT_EXTRA1_VALID    = 0x00000200,
	PLOT_EXTRA2_VALID    = 0x00000400,
	PLOT_EXTRA3_VALID    = 0x00000800,
	PLOT_EXTRA_MASK      = 0x00000F00,

	PLOT_OWN_POS         = 0x00001000,
	PLOT_HEIGHT_IFF      = 0x00002000,

	PLOT_TYPE_SHIFT      = 16,
	PLOT_TYPE_MASK       = 0x000F0000,   //4 bits

	PLOT_SCAN_SHIFT      = 20,
	PLOT_SCAN_MASK       = 0x07F00000,   //7 bits (0.127)
	PLOT_SCAN_VALID      = 0x08000000,

	PLOT_EXTENDED_INFO   = 0x10000000,

//	PLOT_AIS_TX_AVAIL		= 0x20000000,
//	PLOT_AIS_TX_ON			= 0x40000000,

	PLOT_CURRENT         = 0x80000000,

};

enum SURF_EXTINFO_TYPE    //NB Sixteen bits max
{
	SURF_EXTINFO_INVALID = 0,
	SURF_EXTINFO_AIS     = 1,
};

enum SURF_VESSEL_ID
{
	SURF_NEMAS_VES,
	SURF_F145_VES,
	SURF_F146_VES,
	SURF_F147_VES,
	SURF_F148_VES,
	SURF_CST_VESS,
};

#pragma option pop    //return to default enums

class SurfPlotDataDef
{

public:

#pragma option push -a4    //Set compiler to DWORD alignment

	struct FixDataStruct
	{
		int nID;
		double dTime;        //Secs since 01/01/1990
		LatLong LL;
		float fHeight;       //m
		float fSpeed;        //knots
		float fCourse;       //deg
		float afExtra[4];    //can be Heading/RCS/Amplitude
		DWORD dwStatus;

		void Init()
		{
			dwStatus=PLOT_INVALID;
			nID=-1;
			fHeight=-1.0;
         dTime=-1.0;
         LL.Invalidate();
         fSpeed=0.0;
         fCourse=0.0;
         memset(afExtra,0,sizeof(afExtra));
      }

      FixDataStruct()
      {
         Init();
      }

   } P;

#pragma option pop         //Set compiler back to default alignment

	AnsiString sName;
	AnsiString sCallsign;

	struct SurfExtStruct
	{
		BYTE* pucInfo;
      DWORD dwTypeSize;        //Bits[15..0] = size of Info,  Bits[31..16] = Type

      SurfExtStruct()
      {
         pucInfo=NULL;
         dwTypeSize=0;
      }

      ~SurfExtStruct()
      {
         delete[] pucInfo;
      }

      SurfExtStruct& operator = (const SurfExtStruct& T)
      {
         delete[] pucInfo;
         dwTypeSize=T.dwTypeSize;
         int nSize=dwTypeSize&0x0000FFFF;
         if (nSize>0)
            {
            pucInfo=new BYTE[nSize];
            memcpy(pucInfo,T.pucInfo,nSize);
            }
         else
            pucInfo=NULL;
         return *this;
      }

      SurfExtStruct(const SurfExtStruct& T)
      {
         *this=T;
      }


      void Set(const SURF_EXTINFO_TYPE InfoType, const BYTE* pucExtInfo, const WORD wSize)
      {
         dwTypeSize=((DWORD)InfoType<<16)|wSize;
         delete[] pucInfo;
         if (wSize>0)
            {
            pucInfo=new BYTE[wSize];
            memcpy(pucInfo,pucExtInfo,wSize);
            }
         else
            pucInfo=NULL;
      }

      SurfExtStruct(const SURF_EXTINFO_TYPE InfoType, const BYTE* pucExtInfo, const WORD wSize)
      {
         pucInfo=NULL;
         Set(InfoType,pucExtInfo,wSize);
      }

      void SetInfoType(const SURF_EXTINFO_TYPE InfoType)
      {
         dwTypeSize&=0x0000FFFF;
         dwTypeSize|=((DWORD)InfoType<<16);
      }

      SURF_EXTINFO_TYPE GetType() const
      {
         return (SURF_EXTINFO_TYPE)(dwTypeSize>>16);
      }

      WORD wGetSize() const
      {
         return (WORD)(dwTypeSize&0x0000FFFF);
      }

   };

   JList<SurfExtStruct> ExtList;

public:

   void Init()
   {
      P.Init();
      sName=L"";
      sCallsign=L"";
      ExtList.Clear();
   }

	SurfPlotDataDef()
	{
		Init();
	}

	~SurfPlotDataDef()
	{
	}

	void Assign(const SurfPlotDataDef& T)
	{
		P.nID=T.P.nID;
		P.LL=T.P.LL;
		P.fHeight=T.P.fHeight;
		P.dTime=T.P.dTime;
		P.fSpeed=T.P.fSpeed;
		P.fCourse=T.P.fCourse;
		memcpy(P.afExtra,T.P.afExtra,sizeof(P.afExtra));
		P.dwStatus=T.P.dwStatus;
		sName=T.sName;
		sCallsign=T.sCallsign;
		ExtList=T.ExtList;
	}

	void ClearNotFixedVars()
	{
		sName="";
		sCallsign="";
		ExtList.ClearPointers();
	}

	void AssignFixed(const SurfPlotDataDef& T)
	{
		P.nID=T.P.nID;
		P.LL=T.P.LL;
		P.fHeight=T.P.fHeight;
		P.dTime=T.P.dTime;
		P.fSpeed=T.P.fSpeed;
		P.fCourse=T.P.fCourse;
		memcpy(P.afExtra,T.P.afExtra,sizeof(P.afExtra));
		P.dwStatus=T.P.dwStatus;
		sName="";
		sCallsign="";
		ExtList.Clear();
	}

	void Copy(const SurfPlotDataDef T);

	SurfPlotDataDef& operator = (const SurfPlotDataDef& T)
	{
		Assign(T);
		return *this;
	}


	SurfPlotDataDef(const SurfPlotDataDef& T)
	{
		Assign(T);
	}


	bool bPlotValid()
	{
		return (P.dwStatus!=PLOT_INVALID);
	}

	void Invalidate()
	{
		Init();
	}

	void SetID(const int nID)
	{
		P.nID=nID;
		P.dwStatus|=PLOT_ID_VALID;
	}

	bool bIDValid() const
	{
		return (P.dwStatus&PLOT_ID_VALID)!=0;
	}

	int nGetID() const
	{
		return P.nID;
	}

	void SetLL(const LatLong& LL)
	{
		P.LL=LL;
		P.dwStatus|=PLOT_LL_VALID;
	}

	bool bLLValid() const
	{
		return (P.dwStatus&PLOT_LL_VALID)!=0;
	}

	LatLong GetLL() const
	{
		return P.LL;
	}

	void SetTime(const double dTime)
	{
		P.dTime=dTime;
		P.dwStatus|=PLOT_TIME_VALID;
	}

	bool bTimeValid() const
	{
		return (P.dwStatus&PLOT_TIME_VALID)!=0;
	}

	double dGetTime() const
	{
		return P.dTime;
	}

	JTime GetTime() const
	{
		return JTime(P.dTime);
	}

	void SetHeight(const double dHeight)
	{
		P.fHeight=dHeight;
      P.dwStatus|=PLOT_HEIGHT_VALID;
   }

   bool bHeightValid() const
   {
      return (P.dwStatus&PLOT_HEIGHT_VALID)!=0;
   }

   double dGetHeight() const
   {
      return P.fHeight;
   }

   void SetSpeedCourse(const double dSpeed, const double dCourse)
   {
      P.fSpeed=dSpeed;
      P.fCourse=dCourse;
      P.dwStatus|=PLOT_SP_CO_VALID;
   }

   bool bSpeedCourseValid() const
   {
      return (P.dwStatus&PLOT_SP_CO_VALID)!=0;
   }

   double dGetSpeed() const
   {
      return P.fSpeed;
   }

   double dGetCourse() const
   {
      return P.fCourse;
   }

   void SetAngles(const LatLong& SourceLL, const double dAz, const double dEl, const double dRa)
   {
      P.LL=SourceLL;       //Use as line origin
      P.fCourse=dAz;       //Use as line Az
      P.fSpeed=dEl;        //Use as line El
      if (dRa>0.0)
         SetExtra(EXTRA_ANGLES_RA,dRa);
      P.dwStatus|=PLOT_ANGLES_VALID;
   }

   void SetExtra(const int n, const double dV)
   {
      P.afExtra[n]=dV;
      P.dwStatus|=(PLOT_EXTRA0_VALID<<n);
   }

   void SetExtra(const int n, const int nV)
   {
      memcpy(&P.afExtra[n],&nV,sizeof(int));
      P.dwStatus|=(PLOT_EXTRA0_VALID<<n);
   }

   double dGetExtra(const int n) const
   {
      return P.afExtra[n];
   }

   int nGetExtra(const int n) const
   {
      int nV;
      memcpy(&nV,&P.afExtra[n],sizeof(int));
      return nV;
   }

   bool bExtraValid(const int n) const
   {
      return ((P.dwStatus&(PLOT_EXTRA0_VALID<<n))!=0);
   }

   bool bAnglesValid() const
   {
      return (P.dwStatus&PLOT_ANGLES_VALID)!=0;
   }

   void GetAngles(LatLong& SourceLL, double& dAz, double& dEl, double& dRa)
   {
      SourceLL=P.LL;
      dAz=P.fCourse;
      dEl=P.fSpeed;
      if (bExtraValid(0))
         dRa=dGetExtra(0);
      else
         dRa=-1.0;
   }

   void SetOwnPos(const bool bOwn=true)
   {
      if (bOwn)
         P.dwStatus|=PLOT_OWN_POS;
      else
         P.dwStatus&=(~PLOT_OWN_POS);
   }

   bool bOwnPos() const
   {
      return (P.dwStatus&PLOT_OWN_POS)!=0;
   }

   void SetPlotType(const SURF_PLOT_TYPE PlotType)
   {
      P.dwStatus&=(~PLOT_TYPE_MASK);
      P.dwStatus|=((int)PlotType<<PLOT_TYPE_SHIFT);
   }

   SURF_PLOT_TYPE GetPlotType() const
   {
      return (SURF_PLOT_TYPE)((P.dwStatus&PLOT_TYPE_MASK)>>PLOT_TYPE_SHIFT);
   }

	String sGetPlotType() const;

   void SetPlotScan(const int nScan)
   {
      P.dwStatus&=(~PLOT_SCAN_MASK);
      P.dwStatus|=(nScan<<PLOT_SCAN_SHIFT);
      P.dwStatus|=PLOT_SCAN_VALID;
   }

   int nGetPlotScan() const
   {
      if (P.dwStatus&PLOT_SCAN_VALID)
         return (int)((P.dwStatus&PLOT_SCAN_MASK)>>PLOT_SCAN_SHIFT);
      else
         return -1;
   }

	void SetName(const String _sName);
	String sGetName() const;

	bool bNameValid() const
	{
		return (P.dwStatus&PLOT_NAME_VALID)!=0;
	}

	void SetCallsign(const String _sCall);
	String sGetCallsign() const;

	bool bCallsignValid() const
	{
		return (P.dwStatus&PLOT_CALLSIGN_VALID)!=0;
	}

	void SetErrorStatus(const int nError)
	{
      SetExtra(EXTRA_SOURCE_ERR,nError);
   }

   bool bErrorValid() const
   {
      return bExtraValid(EXTRA_SOURCE_ERR);
   }

   int nGetErrorStatus() const
   {
      if (bExtraValid(EXTRA_SOURCE_ERR))
         return nGetExtra(EXTRA_SOURCE_ERR);
      else
         return 0;
   }

   void SetCargo(const int nCargo)
   {
      SetExtra(EXTRA_AIS_CARGO,nCargo);
   }

   int nGetCargo() const
   {
      return nGetExtra(EXTRA_AIS_CARGO);
   }

	String sGetCargo() const;

	bool bCargoValid() const
	{
		return bExtraValid(EXTRA_AIS_CARGO);
	}

	void SetIMO(const int nIMO)
	{
		SetExtra(EXTRA_AIS_IMO,nIMO);
	}

	bool bIMOValid() const
	{
		return bExtraValid(EXTRA_AIS_IMO);
	}

	int nGetIMO() const
	{
		return nGetExtra(EXTRA_AIS_IMO);
	}

	void SetCurrent()
	{
		P.dwStatus|=PLOT_CURRENT;
	}

	bool bCurrentPlot() const
	{
		return (P.dwStatus&PLOT_CURRENT)!=0;
   }

   void ClearCurrent()
   {
      P.dwStatus&=(~PLOT_CURRENT);
   }

   void SetIFFHeight(const bool bIFF)
   {
      if (bIFF)
         P.dwStatus|=PLOT_HEIGHT_IFF;
      else
         P.dwStatus&=(~PLOT_HEIGHT_IFF);
   }

   bool bIFFHeight() const
   {
      return (P.dwStatus&PLOT_HEIGHT_IFF)!=0;
   }

   void SetINSData(const double dHeading,
                   const double dRoll,
                   const double dPitch,
                   const double dHeave,
                   const double dHeadingRate,
                   const double dRollRate,
                   const double dPitchRate,
                   const double dHeaveRate)
   {
      SetExtra(EXTRA_INS_HEADING,dHeading);
      SetExtra(EXTRA_INS_ROLL,dRoll);
      SetExtra(EXTRA_INS_PITCH,dPitch);
		SetExtra(EXTRA_INS_ROLL_ACCEL,0.5);
		SetHeight(dHeave);
		SetSpeedCourse(dRollRate,dPitchRate);
		int nHeaveRate=dHeaveRate*256.0;
		nHeaveRate+=32767;
		nHeaveRate&=0x0000FFFF;
		int nHeadingRate=dHeadingRate*32768.0/45.0;
		nHeadingRate+=32767;
		nHeadingRate&=0x0000FFFF;
		SetID((nHeaveRate<<16)|nHeadingRate);
	}

	bool bINSDataValid() const
	{
		return bExtraValid(EXTRA_INS_HEADING);
	}

	void SetINSRollAccel(const double dRollRate)
	{
		SetExtra(EXTRA_INS_ROLL_ACCEL,dRollRate);
	}

	void GetINSData(double& dHeading,
                   double& dRoll,
                   double& dPitch,
                   double& dHeave,
						 double& dHeadingRate,
						 double& dRollRate,
						 double& dPitchRate,
						 double& dHeaveRate,
						 double& dRollAccel)
	{
		dHeading=dGetExtra(EXTRA_INS_HEADING);
		dRoll=dGetExtra(EXTRA_INS_ROLL);
		dPitch=dGetExtra(EXTRA_INS_PITCH);
		dRollAccel=dGetExtra(EXTRA_INS_ROLL_ACCEL);
		dHeave=-dGetHeight();            //NB Negative Heave is now down
		dRollRate=dGetSpeed();
		dPitchRate=dGetCourse();
		int n=nGetID();
		int nHeaveRate=(int)(n>>16);
		nHeaveRate&=0x0000FFFF;
		nHeaveRate-=32767;
		dHeaveRate=nHeaveRate/256.0;
		dHeaveRate*=-1.0;                //NB Negative Heave is now down
		int nHeadingRate=(int)(n&0x0000FFFF);
		nHeadingRate-=32767;
		dHeadingRate=nHeadingRate*45.0/32768.0;
	}

	void GetINSData(double& dHeading,
						 double& dRoll,
						 double& dPitch,
						 double& dHeave)
	{
		dHeading=dGetExtra(EXTRA_INS_HEADING);
		dRoll=dGetExtra(EXTRA_INS_ROLL);
		dPitch=dGetExtra(EXTRA_INS_PITCH);
		dHeave=-dGetHeight();            //NB Negative Heave is now down
	}


	void GetINSData_BLAH( double& dHeading,
								 double& dRoll,
								 double& dPitch,
								 double& dHeave,
								 double& dHeadingRate,
								 double& dRollRate,
								 double& dPitchRate,
								 double& dHeaveRate,
								 double& dRollAccel) const
	{
		dHeading=dGetExtra(EXTRA_INS_HEADING);
		dRoll=dGetExtra(EXTRA_INS_ROLL);
		dPitch=dGetExtra(EXTRA_INS_PITCH);
		dRollAccel=dGetExtra(EXTRA_INS_ROLL_ACCEL);
		dHeave=dGetHeight();            //NB Positive Heave is DOWN for BLAH
		dRollRate=dGetSpeed();
		dPitchRate=dGetCourse();
		int n=nGetID();
		int nHeaveRate=(int)(n>>16);
		nHeaveRate&=0x0000FFFF;
		nHeaveRate-=32767;
		dHeaveRate=nHeaveRate/256.0;    //NB Positive Heave is DOWN for BLAH
		int nHeadingRate=(int)(n&0x0000FFFF);
		nHeadingRate-=32767;
		dHeadingRate=nHeadingRate*45.0/32768.0;
	}


   double dGetINSRollRate() const
   {
      return dGetSpeed();
   }

	void GetINSRoll(double& dRoll, double& dRollRate, double& dRollAccel)
	{
		dRoll=dGetExtra(EXTRA_INS_ROLL);
		dRollRate=dGetSpeed();
		dRollAccel=dGetExtra(EXTRA_INS_ROLL_ACCEL);
	}

   double dGetINSPitchRate() const
   {
      return dGetCourse();
   }

   void GetINSPitch(double& dPitch, double& dPitchRate)
   {
      dPitch=dGetExtra(EXTRA_INS_PITCH);
      dPitchRate=dGetCourse();
   }

   double dGetINSHeaveRate() const
   {
      int n=nGetID();
      int nHeaveRate=(int)(n>>16);
      nHeaveRate&=0x0000FFFF;
      nHeaveRate-=32767;
      double dHeaveRate=nHeaveRate/256.0;
      dHeaveRate*=-1.0;                //NB Negative Heave is now down
      return dHeaveRate;
	}

	void GetINSHeave_BLAH(double& dHeave, double& dHeaveRate)
   {
//      dHeave=-dGetHeight();            //NB Negative Heave is now down
		dHeave=dGetHeight();                //NB Positive Down Again JGT 16/09/2010
		int n=nGetID();
      int nHeaveRate=(int)(n>>16);
		nHeaveRate&=0x0000FFFF;
      nHeaveRate-=32767;
      dHeaveRate=nHeaveRate/256.0;
//      dHeaveRate*=-1.0;                //NB Positive Heave Rate again
	}

	void SetINSHeave_BLAH(const double dHeave, const double dHeaveRate)
   {
      SetHeight(dHeave);
		int n=nGetID();
      int nHeaveRate=dHeaveRate*256.0;
      nHeaveRate+=32767;
      nHeaveRate&=0x0000FFFF;
      n&=0x0000FFFF;
      SetID((nHeaveRate<<16)|n);
   }

   double dGetINSHeading() const
   {
      return dGetExtra(EXTRA_INS_HEADING);
   }

   double dGetINSHeadingRate() const
   {
      int n=nGetID();
      int nHeadingRate=(int)(n&0x0000FFFF);
      nHeadingRate-=32767;
      return nHeadingRate*45.0/32768.0;
   }

   int nAddExtInfo(const SURF_EXTINFO_TYPE InfoType, const BYTE* pucInfo, const WORD wSize);

   bool bExtInfoAvail() const
   {
      return ((P.dwStatus&PLOT_EXTENDED_INFO)!=0);
   }

   int nExtInfoCount()
   {
      if (bExtInfoAvail())
         return ExtList.nGetCount();
      return 0;
   }

   SURF_EXTINFO_TYPE GetExtInfoType(const int nIndex)
   {
      return ExtList[nIndex]->GetType();
   }

   int nGetExtInfoSize(const int nIndex)
   {
      return (int)ExtList[nIndex]->wGetSize();
   }

   void GetExtInfo(const int nIndex, BYTE* pucInfo)
   {
      memcpy(pucInfo,ExtList[nIndex]->pucInfo,ExtList[nIndex]->wGetSize());
   }


   void ClearExtInfo()
   {
      P.dwStatus&=(~PLOT_EXTENDED_INFO);
      ExtList.Clear();
   }

/*
	void SetAISTXOn(const  bool bTX_On)
	{
		P.dwStatus|=PLOT_AIS_TX_AVAIL;
		if (bTX_On)
			P.dwStatus|=PLOT_AIS_TX_ON;
		else
			P.dwStatus&=(~PLOT_AIS_TX_ON);
	}

	void ClearAISTXAvail()
	{
		P.dwStatus&=(~PLOT_AIS_TX_AVAIL);
	}

	bool bAISTXAvail() const
	{
		return (P.dwStatus&PLOT_AIS_TX_AVAIL)!=0;
	}

	bool bAISTXOn() const
	{
		if (bAISTXAvail())
			return (P.dwStatus&PLOT_AIS_TX_ON)!=0;
		else
			return false;
	}
*/

};

class SurfMsg
{
	int nSourceID;
	JList <SurfPlotDataDef> PlotList;
	int nBufSize;

   enum
   {
      MAX_PLOTS_IN_MSG  = 1024,
   };

public:

   SurfMsg()
   {
	}

	SurfMsg& operator = (const SurfMsg& S)
	{
		nSourceID=S.nSourceID;
		PlotList=S.PlotList;
		return *this;
	}

	SurfMsg(const SurfMsg& S)
	{
		*this=S;
	}

   ~SurfMsg()
   {
   }

   void SetSourceID(const int _nID)
   {
      nSourceID=_nID;
   }

   int nGetSourceID() const
   {
      return nSourceID;
   }


   int nGetCount() const
   {
      return PlotList.nGetCount();
   }

   void AddPlot(SurfPlotDataDef& Plot)
   {
      SurfPlotDataDef* pPlot=new SurfPlotDataDef;
      *pPlot=Plot;
      PlotList.nAdd(pPlot);
      PlotList.Pack();
   }

   SurfPlotDataDef& GetPlot(const int n)
   {
      return *PlotList[n];
   }


   void IncOffs(int &nOffs, const int nSize) const
   {
      if (nOffs+nSize<nBufSize)
         nOffs+=nSize;
   }

   int nGetBuffer(BYTE* pucBuf, const int _nBufSize=0x7FFFFFFF);
   bool bCreateMsg(const BYTE* pucBuf, const int nMsgSize);


};

class SurfStoreClass
{
   CstMessages Cst;
	String sFile;
	String sBackFile;
	bool bStored;
	double dNextStoreSec;
	double dNextStoreBackSec;
	String sFileExt;
   JTime FirstTime;

public:

	SurfStoreClass(const SURF_VESSEL_ID Vessel, const CST_DATA_SOURCE Src, const String sDescr, const String sExt, const LatLong& LL, const double dHeight, const double dSec);
	~SurfStoreClass();

   void AddPlot(SurfPlotDataDef& Plot, const double dSec);

	bool bStoreFile(const String sBaseFolder=L"");


};


//-----------------------------------------------------------

class SurfRXClass
{

   enum MSG_STATE
   {
      MSG_STATE_S,
      MSG_STATE_U,
      MSG_STATE_R,
      MSG_STATE_F,
      MSG_STATE_P,
      MSG_STATE_L,
      MSG_STATE_O,
      MSG_STATE_T,
      MSG_STATE_SIZE_0,
      MSG_STATE_SIZE_1,
      MSG_STATE_SIZE_2,
      MSG_STATE_SIZE_3,
      MSG_STATE_DATA,
   } MsgState;

   enum
   {
      MAX_RX_SIZE    = 65536,
   };

   BYTE aucMsgBuf[MAX_RX_SIZE];
   int nMsgBufOffs;
   int nMsgSize;
   SurfMsg Msg;

public:

   SurfRXClass();
   ~SurfRXClass();

   void Init();

   bool bAddByte(const BYTE uc);

   SurfMsg& GetMsg()
   {
      return Msg;
   };

};

class SurfRequest
{

   enum MSG_STATE
   {
      MSG_STATE_S,
      MSG_STATE_U,
      MSG_STATE_R1,
      MSG_STATE_F,
      MSG_STATE_R2,
      MSG_STATE_E,
      MSG_STATE_Q,
      MSG_STATE_ID,
      MSG_STATE_REQ,
   } MsgState;

   BYTE aMsg[9];
   int nReqID;

public:

   SurfRequest()
   {
      MsgState=MSG_STATE_S;
      nReqID=-1;
   }

   void Init()
   {
      MsgState=MSG_STATE_S;
      nReqID=-1;
   }

   BYTE* pucMsg(const int nID, const SURF_REQUEST Request)
   {
      aMsg[0]='S';
      aMsg[1]='U';
      aMsg[2]='R';
      aMsg[3]='F';
      aMsg[4]='R';
      aMsg[5]='E';
      aMsg[6]='Q';
      aMsg[7]=nID;
      aMsg[8]=Request;
      return aMsg;
   }

   int nGetMsgSize() const
   {
      return 9;
   }

   SURF_REQUEST AddByte(const BYTE uc);

   int nGetRequestID() const
   {
      return nReqID;
   }

};

//-----------------------------------------------------------

enum SURF_PREDEF_LOCATION
{
   SURF_NEMAS_LOC    = 1,
   SURF_ITB_LOC      = 20,
   SURF_FSG_LOC      = 50,
   SURF_209_LOC      = 80,
   SURF_CST_LOC      = 128,
   SURF_UNKNOWN_LOC  = 200,
};

enum
{
   SURF_PREDEF_OWN_ID   = 0,
   SURF_PREDEF_TIS_ID   = SURF_NEMAS_LOC,
   SURF_PREDEF_HUB_ID   = SURF_CST_LOC,
};

struct SurfPredefDevice
{
   SURF_PREDEF_LOCATION Loc;
	String sDescr;
	String sExt;
   int nID;

	SurfPredefDevice(SURF_PREDEF_LOCATION _Loc, String _sDescr, String _sExt, int _nID);

	SurfPredefDevice()
	{
      Loc=SURF_UNKNOWN_LOC;
      sDescr=L"";
      sExt=L"";
      nID=-1;
   }

};

class SurfPredefDevices
{

   JList<SurfPredefDevice> Dev;

public:

   SurfPredefDevices();

	bool bImportCSV(const String sFile);

	void Add(SURF_PREDEF_LOCATION Loc, String sDescr, String sExt, int nLocID);

   int nCount() const
   {
      return Dev.nGetCount();
   }

   SURF_PREDEF_LOCATION Location(const int n)
   {
      return Dev[n]->Loc;
   }

   int nID(const int n)
   {
      return Dev[n]->nID;
   }

	String sDescr(const int n);
	String sExt(const int n);

	int nFindIndex(const int nID);

	int nFindIndex(const String sDescr, const SURF_PREDEF_LOCATION Loc);
	int nFindID(const String sDescr, const SURF_PREDEF_LOCATION Loc);

	int nFindExtIndex(const String sExt);
	int nFindExtID(const String sExt);

};

//-----------------------------------------------------------


#endif
