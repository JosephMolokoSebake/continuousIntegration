//---------------------------------------------------------------------------

#include <jpch.h>
#pragma hdrstop

#include "SurfMonitorDlg.h"
#include "SurfDefs.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "NumEdit"
#pragma resource "*.dfm"
TSurfMonitorForm *SurfMonitorForm;
//---------------------------------------------------------------------------
__fastcall TSurfMonitorForm::TSurfMonitorForm(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TSurfMonitorForm::FormCreate(TObject * /*Sender*/)
{
   nServerPort=SURF_2_DEVICE_PORT;   //Data from surface plot
   SurfRX.Init();
   pServers=NULL;
   nServer=-1;
}
//---------------------------------------------------------------------------
void __fastcall TSurfMonitorForm::FormShow(TObject * /*Sender*/)
{
   pServers=new LJTcpServerSockets(5,false,true,5);
   nServer=pServers->nAddServer(this,nServerPort);
   if (nServer>=0)
      pServers->ListenForSocketConnect(nServer);

   SetLine(0,S0Ed,I0Ed,M0Ed,R0Rad);
   SetLine(1,S1Ed,I1Ed,M1Ed,R1Rad);
   SetLine(2,S2Ed,I2Ed,M2Ed,R2Rad);
   SetLine(3,S3Ed,I3Ed,M3Ed,R3Rad);
   SetLine(4,S4Ed,I4Ed,M4Ed,R4Rad);
   SetLine(5,S5Ed,I5Ed,M5Ed,R5Rad);
   SetLine(6,S6Ed,I6Ed,M6Ed,R6Rad);
   SetLine(7,S7Ed,I7Ed,M7Ed,R7Rad);

   CloseBut->SetFocus();

   bStopTimer=false;
   Timer->Interval=100;
   Timer->Enabled=true;

}
//---------------------------------------------------------------------------
void __fastcall TSurfMonitorForm::FormClose(TObject * /*Sender*/,
      TCloseAction & /*Action*/)
{
   bStopTimer=true;
   while(Timer->Enabled)
      Application->ProcessMessages();
   delete pServers;
   pServers=NULL;
}
//---------------------------------------------------------------------------
void __fastcall TSurfMonitorForm::FormDestroy(TObject * /*Sender*/)
{
//
}
//---------------------------------------------------------------------------
void __fastcall TSurfMonitorForm::TimerTimer(TObject * /*Sender*/)
{
   if (bStopTimer)
      Timer->Enabled=false;
   else
      {
      if ((pServers)&&(nServer>=0))
         {
         BYTE* pucData=new BYTE[MAX_RX_DATA];
         int nRXSize=pServers->nReadData(nServer,pucData,MAX_RX_DATA);
         if (nRXSize>0)
            ProcessData(pucData,nRXSize);
         delete[] pucData;
         }
      }
}
//---------------------------------------------------------------------------

void __fastcall TSurfMonitorForm::ProcessData(const BYTE* pucData, const int nSize)
{
   for (int i=0; i<nSize; i++)
      {
      if (SurfRX.bAddByte(pucData[i]))
         {
         SurfMsg Msg;
         Msg=SurfRX.GetMsg();
         int nID=Msg.nGetSourceID();
         bool bFound=false;
         int nLine=-1;
         for (int i=0; (i<StatList.nGetCount())&&(!bFound); i++)
            {
            if (StatList[i]->nID==nID)
               {
               apMsgEd[i]->SetVal(++StatList[i]->nMsgCount);
               nLine=i;
               bFound=true;
               }
            }
         if ((!bFound)&&(StatList.nGetCount()<8))
            {
            StatStruct* pStat=new StatStruct;
            pStat->nID=nID;
            pStat->nMsgCount=1;
            StatList.nAdd(pStat);
            StatList.Pack();
            int n=StatList.nGetCount()-1;
            apIDEd[n]->SetVal(nID);
            apMsgEd[n]->SetVal(1);
            apRad[n]->Enabled=true;
            int nDev;
            switch(nID)
               {
               case SURF_PREDEF_OWN_ID:
                  apSourceEd[n]->Text=L"Own Position";
                  break;
               case SURF_PREDEF_TIS_ID:
                  apSourceEd[n]->Text=L"NEMAS TIS";
                  break;
               default:
                  nDev=Dev.nFindIndex(nID);
                  if (nDev>=0)
                     apSourceEd[n]->Text=Dev.sDescr(nDev);
               }
            nLine=n;
            }
         if (nLine>=0)
            {
            if (apRad[nLine]->Checked)
               {
               DispMemo->Clear();
               String s;
               if (Msg.nGetCount()>1)
                  s.printf(L"%d Plots in Message",Msg.nGetCount());
               else
                  s.printf(L"%d Plot in Message",Msg.nGetCount());
               DispMemo->Lines->Add(s);
               for (int i=0; i<Msg.nGetCount(); i++)
                  {
                  SurfPlotDataDef Plot;
                  Plot=Msg.GetPlot(i);
                  double dAz,dEl,dRa;
                  LatLong LL;
                  switch(Plot.GetPlotType())
                     {
                     case PLOT_TYPE_ANGLES:
                        Plot.GetAngles(LL,dAz,dEl,dRa);
                        if (dRa>0.0)
                           s.printf(L"%02d  Az: %2.2f   El: %2.2f  Ra: %0.0f",i+1,dAz,dEl,dRa);
                        else
                           s.printf(L"%02d  Az: %2.2f   El: %2.2f",i+1,dAz,dEl);
                        break;
                     default:
                        s.printf(L"%02d ",i+1);
                        s=s+Plot.GetLL().sLat()+" "+Plot.GetLL().sLong();
                     }
                  DispMemo->Lines->Add(s);
                  }
               }
            }
         }
      }

}

