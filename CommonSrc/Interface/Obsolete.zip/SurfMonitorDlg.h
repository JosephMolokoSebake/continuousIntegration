//---------------------------------------------------------------------------

#ifndef SurfMonitorDlgH
#define SurfMonitorDlgH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include "NumEdit.h"
#include <Vcl.Buttons.hpp>
#include <Vcl.ExtCtrls.hpp>
#include <System.Win.ScktComp.hpp>

#include "JList.h"
#include "SurfDefs.h"
#include "LJTcpServerSocket.h"


//---------------------------------------------------------------------------
class TSurfMonitorForm : public TForm
{
__published:	// IDE-managed Components
   TLabel *Label1;
   TLabel *Label2;
   TEdit *S0Ed;
   JNumEdit *I0Ed;
   JNumEdit *M0Ed;
   TLabel *Label3;
   TEdit *S1Ed;
   JNumEdit *I1Ed;
   JNumEdit *M1Ed;
   TEdit *S2Ed;
   JNumEdit *I2Ed;
   JNumEdit *M2Ed;
   TEdit *S3Ed;
   JNumEdit *I3Ed;
   JNumEdit *M3Ed;
   TEdit *S4Ed;
   JNumEdit *I4Ed;
   JNumEdit *M4Ed;
   TEdit *S5Ed;
   JNumEdit *I5Ed;
   JNumEdit *M5Ed;
   TEdit *S6Ed;
   JNumEdit *I6Ed;
   JNumEdit *M6Ed;
   TEdit *S7Ed;
   JNumEdit *I7Ed;
   JNumEdit *M7Ed;
   TBitBtn *CloseBut;
   TTimer *Timer;
   TMemo *DispMemo;
   TLabel *Label4;
   TRadioButton *R0Rad;
   TRadioButton *R1Rad;
   TRadioButton *R2Rad;
   TRadioButton *R3Rad;
   TRadioButton *R4Rad;
   TRadioButton *R5Rad;
   TRadioButton *R6Rad;
   TRadioButton *R7Rad;
   void __fastcall FormCreate(TObject *Sender);
   void __fastcall FormShow(TObject *Sender);
   void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
   void __fastcall FormDestroy(TObject *Sender);
   void __fastcall TimerTimer(TObject *Sender);
private:	// User declarations

   TEdit* apSourceEd[8];
   JNumEdit* apIDEd[8];
   JNumEdit* apMsgEd[8];
   TRadioButton* apRad[8];

   LJTcpServerSockets* pServers;
   int nServer;

   bool bStopTimer;

   struct StatStruct
   {
      String sName;
      int nID;
      int nMsgCount;

      StatStruct()
      {
         sName=L"";
         nID=-1;
         nMsgCount=0;
      }

   };

   JList<StatStruct> StatList;

   enum
   {
      MAX_RX_DATA = 65536,
   };

   SurfRXClass SurfRX;

   SurfPredefDevices Dev;

   int nServerPort;

   void SetLine(const int n, TEdit* pS, JNumEdit* pI, JNumEdit* pM, TRadioButton* pR)
   {
      apSourceEd[n]=pS;
      apIDEd[n]=pI;
      apMsgEd[n]=pM;
      apRad[n]=pR;
   }

   void __fastcall ProcessData(const BYTE* pucData, const int nSize);


public:		// User declarations
   __fastcall TSurfMonitorForm(TComponent* Owner);

   void __fastcall SetPort(const int _nPort)
   {
      nServerPort=_nPort;
   }

};
//---------------------------------------------------------------------------
extern PACKAGE TSurfMonitorForm *SurfMonitorForm;
//---------------------------------------------------------------------------
#endif
