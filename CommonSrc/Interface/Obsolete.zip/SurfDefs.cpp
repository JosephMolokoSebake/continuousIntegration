//---------------------------------------------------------------------------
#include "jpch.h"

#pragma hdrstop

#include "SurfDefs.h"
#include "JUtils.h"
#include "JCommaText.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)

void SurfPlotDataDef::Copy(const SurfPlotDataDef T)
{
   P.nID=T.P.nID;
   P.LL=T.P.LL;
   P.fHeight=T.P.fHeight;
   P.dTime=T.P.dTime;
   P.fSpeed=T.P.fSpeed;
   P.fCourse=T.P.fCourse;
   memcpy(P.afExtra,T.P.afExtra,sizeof(P.afExtra));
   P.dwStatus=T.P.dwStatus;
   sName=T.sName;
   sCallsign=T.sCallsign;
   ExtList=T.ExtList;
}

void SurfPlotDataDef::SetName(const String _sName)
{
	sName=_sName;
   P.dwStatus|=PLOT_NAME_VALID;
}

String SurfPlotDataDef::sGetName() const
{
   return sName;
}

void SurfPlotDataDef::SetCallsign(const String _sCall)
{
	sCallsign=_sCall;
	P.dwStatus|=PLOT_CALLSIGN_VALID;
}

int SurfPlotDataDef::nAddExtInfo(const SURF_EXTINFO_TYPE InfoType, const BYTE* pucInfo, const WORD wSize)
{
   int n=ExtList.nGetCount();
   if (n<65535)
      {
      P.dwStatus|=PLOT_EXTENDED_INFO;
      n=ExtList.nAdd(new SurfExtStruct(InfoType,pucInfo,wSize));
      ExtList.Pack();
		}
	return n;
}

String SurfPlotDataDef::sGetCargo() const
{
	int nCargo=nGetExtra(EXTRA_AIS_CARGO);
	CstShipInfo Info;
	Info.SetCargo(nCargo);
	return Info.sGetCargo();
}

String SurfPlotDataDef::sGetCallsign() const
{
   return sCallsign;
}

String SurfPlotDataDef::sGetPlotType() const
{
	switch(GetPlotType())
		{
		case PLOT_TYPE_PLOT:
			return "MRR Plot";
		case PLOT_TYPE_PSR_AIR:
			return "PSR Air";
		case PLOT_TYPE_SEC:
			return "Secondary";
		case PLOT_TYPE_ASSOC:
			return "Associated";
		case PLOT_TYPE_PSR_3D:
			return "PSR 3D";
		case PLOT_TYPE_AIS:
			return "AIS Target";
		case PLOT_TYPE_SINGLE:
			return "Tracker";
		case PLOT_TYPE_ANGLES:
			return "Angles";
		case PLOT_TYPE_CANCEL:
			return "Track Cancel";
		case PLOT_TYPE_OWNPOS:
			return "Own Position";
		case PLOT_TYPE_INS:
			return "INS";
		case PLOT_TYPE_PSR_CMS:
			return "PSR CMS";
		case PLOT_TYPE_PSR_MEM:
			return "PSR Memory";
		case PLOT_TYPE_PSR_SURF:
			return "PSR Surface";
		case PLOT_TYPE_PSR_TWS:
			return "PSR TWS";
		case PLOT_TYPE_PSR_SPLASH:
			return "PSR Splash";
		default:
			return "Unknown";
		}
}


//Construct the packet buffer that will be sent to the remote site
//Data will be returned in pucBuf, with the buffer size as function return
int SurfMsg::nGetBuffer(BYTE* pucBuf, const int _nBufSize)
{
	nBufSize=_nBufSize;
	memcpy(pucBuf,"SURFPLOT",8);    //Header
	int nOffs=sizeof(nOffs)+8;      //Add header size to offset (leave space for the buffer size)

	//Add source ID
	memcpy(&pucBuf[nOffs],&nSourceID,sizeof(nSourceID));
   IncOffs(nOffs,sizeof(nSourceID));

   //Add Number of Plots available
   int nPlots=PlotList.nGetCount();
   memcpy(&pucBuf[nOffs],&nPlots,sizeof(nPlots));
   IncOffs(nOffs,sizeof(nPlots));

   //Add all the plots
   for (int i=0; i<nPlots; i++)
      {
      //Add fixed length data portion of plot
      memcpy(&pucBuf[nOffs],&PlotList[i]->P,sizeof(PlotList[i]->P));
      IncOffs(nOffs,sizeof(PlotList[i]->P));

      //Add Plot Target Name if available
		if (PlotList[i]->bNameValid())
			{
			AnsiString s=PlotList[i]->sGetName();
			int n=s.Length();
			memcpy(&pucBuf[nOffs],&n,sizeof(n));
			IncOffs(nOffs,sizeof(n));
			if (n>0)
				{
				memcpy(&pucBuf[nOffs],s.c_str(),n);
				IncOffs(nOffs,n);
				}
			}

		//Add Plot Target callsign if available
		if (PlotList[i]->bCallsignValid())
			{
			AnsiString s=PlotList[i]->sGetCallsign();
			int n=s.Length();
			memcpy(&pucBuf[nOffs],&n,sizeof(n));
			IncOffs(nOffs,sizeof(n));
			if (n>0)
				{
				memcpy(&pucBuf[nOffs],s.c_str(),n);
				IncOffs(nOffs,n);
				}
			}
		//Add Plot Target extended info if available
		WORD wExt=(WORD)PlotList[i]->nExtInfoCount();
		if (wExt>0)
			{
			memcpy(&pucBuf[nOffs],&wExt,sizeof(wExt));
         IncOffs(nOffs,sizeof(wExt));
         for (WORD j=0; j<wExt; j++)
            {
            DWORD dw=PlotList[i]->ExtList[j]->dwTypeSize;
            memcpy(&pucBuf[nOffs],&dw,sizeof(dw));
            IncOffs(nOffs,sizeof(dw));
            int n=PlotList[i]->nGetExtInfoSize(j);
            if (n>0)
               {
               memcpy(&pucBuf[nOffs],PlotList[i]->ExtList[j]->pucInfo,n);
               IncOffs(nOffs,n);
               }
            }
         }
      }
   nOffs-=8;         //Subtract header size
   //Insert the size of the buffer (without header) into the buffer
   memcpy(&pucBuf[8],&nOffs,sizeof(nOffs));
   return nOffs+8;   //Message Size to send includes header
}

//Decode the received packet buffer to extract the plots (the 8 byte header
//has already been stripped).
//Extracted plots will be stored in PlotList
//Returns true for success
//See SurfRXClass::bAddByte for usage example

bool SurfMsg::bCreateMsg(const BYTE* pucBuf, const int nMsgSize)
{
   PlotList.Clear();          //Clear List
   int nOffs=sizeof(nOffs);

   //Get Source ID
   memcpy(&nSourceID,&pucBuf[nOffs],sizeof(nSourceID));
   nOffs+=sizeof(nSourceID);

   //Get Number of Plots
   int nPlots;
   memcpy(&nPlots,&pucBuf[nOffs],sizeof(nPlots));
   nOffs+=sizeof(nPlots);

   //Get Plot info
   if ((nPlots>0)&&(nPlots<=MAX_PLOTS_IN_MSG))
      {
      bool bOK=true;
      for (int i=0; (i<nPlots)&&(bOK); i++)
         {
         SurfPlotDataDef* pPlot=new SurfPlotDataDef;     //Create new plot instance
         //Get fixed length data
         memcpy(&pPlot->P,&pucBuf[nOffs],sizeof(pPlot->P));
         nOffs+=sizeof(pPlot->P);
         //Get Name if available
         if (pPlot->bNameValid())
            {
            int n;
            memcpy(&n,&pucBuf[nOffs],sizeof(n));
            if (nOffs+(int)sizeof(n)+n>nMsgSize)
               bOK=false;
            else
               {
               nOffs+=sizeof(n);
               if (n>0)
                  {
                  char szSt[1024];
                  memcpy(szSt,&pucBuf[nOffs],n);
                  szSt[n]=0;
                  pPlot->SetName(szSt);
                  nOffs+=n;
                  }
               }
            }
         //Get Callsign if available
         if (pPlot->bCallsignValid())
            {
            int n;
            memcpy(&n,&pucBuf[nOffs],sizeof(n));
            if (nOffs+(int)sizeof(n)+n>nMsgSize)
               bOK=false;
            else
               {
               nOffs+=sizeof(n);
               if (n>0)
                  {
                  char szSt[1024];
                  memcpy(szSt,&pucBuf[nOffs],n);
                  szSt[n]=0;
                  pPlot->SetCallsign(szSt);
                  nOffs+=n;
                  }
               }
            }
         pPlot->ExtList.Clear();    //Do not clear PLOT_EXTENDED_INFO bit
         if (pPlot->bExtInfoAvail())
            {
            WORD wExtCnt;
            memcpy(&wExtCnt,&pucBuf[nOffs],sizeof(wExtCnt));
            if (nOffs+(int)sizeof(wExtCnt)>nMsgSize)
               bOK=false;
            else
               {
               nOffs+=sizeof(wExtCnt);
               for (int j=0; (j<wExtCnt)&&(bOK); j++)
                  {
                  DWORD dw;
                  memcpy(&dw,&pucBuf[nOffs],sizeof(dw));
                  WORD wSize=(WORD)(dw&0x0000FFFF);
                  if (nOffs+(int)(sizeof(dw)+wSize)>nMsgSize)
                     bOK=false;
                  else
                     {
                     nOffs+=sizeof(dw);
                     SURF_EXTINFO_TYPE InfoType=(SURF_EXTINFO_TYPE)(dw>>16);
                     pPlot->ExtList.nAdd(new SurfPlotDataDef::SurfExtStruct(InfoType,&pucBuf[nOffs],wSize));
                     nOffs+=wSize;
                     }
                  }
               }
            pPlot->ExtList.Pack();
            }
         if (bOK)
            PlotList.nAdd(pPlot);   //Add plot to PlotList
         }
      PlotList.Pack();  //Pack PlotList
      return true;
      }
   return false;
}

SurfStoreClass::SurfStoreClass(const SURF_VESSEL_ID Vessel, const CST_DATA_SOURCE Src, const String sDescr, const String sExt, const LatLong& LL, const double dHeight, const double dSec)
{
	sFileExt=sExt;
	FirstTime.Invalidate();
	if (dSec<-0.0001)
      sFile=L"";
   else
      sFile=JTime(true).sFileName(sExt);
   switch(Vessel)
      {
      case SURF_F145_VES:
         sFile=L"F145_"+sFile;
         break;
      case SURF_F146_VES:
         sFile=L"F146_"+sFile;
         break;
      case SURF_F147_VES:
         sFile=L"F147_"+sFile;
         break;
      case SURF_F148_VES:
         sFile=L"F148_"+sFile;
         break;
      default: ;  //No prefix for NEMAS or Coastrad
      }
   if (dSec<-0.0001)
      sBackFile=L"";
   else
      sBackFile=sFileNewExt(sFile,L".~"+sExt);
   bStored=false;
   Cst.SetSource(Src,LL,dHeight,sDescr);
   dNextStoreSec=dSec+60.0;
   dNextStoreBackSec=-1.0;  //Do not setup backup store
}

SurfStoreClass::~SurfStoreClass()
{
   if (!bStored)
      bStoreFile();
}

void SurfStoreClass::AddPlot(SurfPlotDataDef& Plot, const double dSec)
{
   CstMessage Msg;
   if (Plot.bIDValid())
      {
      int nID=Plot.nGetID();
      bool bPositive=(nID>=0);
      nID=abs(nID);
      if (Cst.GetSource()==CST_MRR_SRC)
         Msg.SetMRRID(nID,bPositive);    //if positive, it is an IFF squawk
      else if (bPositive)
         Msg.SetMMSI(nID);
      else
         Msg.SetTrack(nID);
      }
   if (Plot.bLLValid())
      Msg.SetLL(Plot.GetLL());
   if (Plot.bHeightValid())
      Msg.SetHeightM(Plot.dGetHeight());
   if (Plot.bTimeValid())
      Msg.SetTime(Plot.dGetTime());
   if (!FirstTime.bValid())
      FirstTime=Plot.GetTime();
   if (Cst.GetSource()==CST_MRR_SRC)
      {
      CST_MRR_TARGET_TYPE TType;
      switch(Plot.GetPlotType())
         {
         case PLOT_TYPE_ASSOC:
            TType=CST_MRR_ASSOC_TYPE;
            break;
         case PLOT_TYPE_PSR_AIR:
            TType=CST_MRR_PRI_TYPE;
            Msg.SetMRRTrackType(CST_MRR_AIR_TRACK);
            break;
         case PLOT_TYPE_SEC:
            TType=CST_MRR_SEC_TYPE;
            break;
         case PLOT_TYPE_PSR_3D:
            TType=CST_MRR_PRI_TYPE;
            Msg.SetMRRTrackType(CST_MRR_3D_TRACK);
            break;
         case PLOT_TYPE_PSR_CMS:
            TType=CST_MRR_PRI_TYPE;
            Msg.SetMRRTrackType(CST_MRR_CMS_TRACK);
            break;
         case PLOT_TYPE_PSR_MEM:
            TType=CST_MRR_PRI_TYPE;
            Msg.SetMRRTrackType(CST_MRR_MEM_TRACK);
            break;
         case PLOT_TYPE_PSR_SURF:
            TType=CST_MRR_PRI_TYPE;
            Msg.SetMRRTrackType(CST_MRR_SURFACE_TRACK);
            break;
         case PLOT_TYPE_PSR_TWS:
            TType=CST_MRR_PRI_TYPE;
            Msg.SetMRRTrackType(CST_MRR_TWS_TRACK);
            break;
         case PLOT_TYPE_PSR_SPLASH:
            TType=CST_MRR_PRI_TYPE;
            Msg.SetMRRTrackType(CST_MRR_SPLASH_TRACK);
            break;
         case PLOT_TYPE_CANCEL:
            TType=CST_MRR_CANCEL_TYPE;
            break;
         default:
            TType=CST_MRR_PLOT_TYPE;
         }
      Msg.SetMRRTargetType(TType);
      Msg.SetMRRIFFHeight(Plot.bIFFHeight());
      }
   if (Plot.bSpeedCourseValid())
      {
      Msg.SetSpeed(Plot.dGetSpeed());
      Msg.SetCourse(Plot.dGetCourse());
      }
   if ((Plot.bNameValid()||Plot.bCallsignValid()||(Plot.bExtInfoAvail()))&&(Plot.bIDValid()))
      {
      Cst.AddMsg(Msg,Plot.bNameValid(),Plot.bCallsignValid(),Plot.bIMOValid());
      CstShipInfo Info;
      Info.SetMMSI(Msg.nGetMMSI());
      if (Plot.bNameValid())
         Info.SetName(Plot.sGetName());
      if (Plot.bCallsignValid())
         Info.SetCallsign(Plot.sGetCallsign());
      if (Plot.bIMOValid())
         Info.SetIMO(Plot.nGetIMO());
      if (Plot.bCargoValid())
         Info.SetCargo(Plot.nGetCargo());
      for (int i=0; i<Plot.nExtInfoCount(); i++)
         {
         int nSize=Plot.nGetExtInfoSize(i);
         if (nSize>0)
            {
            BYTE* pucExt=new BYTE[nSize];
            Plot.GetExtInfo(i,pucExt);
            Info.nAddExtInfo((CST_EXTINFO_TYPE)Plot.GetExtInfoType(i),pucExt,nSize);
            delete[] pucExt;
            }
         }
      Cst.AddInfo(&Info);
      }
   else
      Cst.AddMsg(Msg);
   bStored=false;
   if (!sFile.IsEmpty())
      {
      if (dSec>=dNextStoreSec)
         {
         bStored=(Cst.Store(sFile)==JFile::F_NO_ERROR);
         dNextStoreSec=dSec+60.0;
         dNextStoreBackSec=dSec+30.0;
         }
      if ((dSec>=dNextStoreBackSec)&&(dNextStoreBackSec>0.0))
         {
         bStored=(Cst.Store(sBackFile)==JFile::F_NO_ERROR);
         dNextStoreBackSec=-1.0;
         }
      }
}

bool SurfStoreClass::bStoreFile(const String sBaseFolder)
{
   if (Cst.nGetCount()>0)
      {
      if (sFile.IsEmpty())
         sFile=FirstTime.sFileName(sFileExt);
//      bool bCompress=Cst.GetSource()==CST_VTS_AIS_SRC;   //Compress AIS Data
      bStored=(Cst.Store(sFile,false)==JFile::F_NO_ERROR);
      if (!sBackFile.IsEmpty())
         bStored=(Cst.Store(sBackFile,false)==JFile::F_NO_ERROR);
      if (!sBaseFolder.IsEmpty())
         {
			String sExt=sFileExtOnly(sFile);
			String sDestFolder=IncludeTrailingBackslash(sBaseFolder)+sExt;
			if (bCreateDir(sDestFolder,false))
				{
				String sDestFile=IncludeTrailingBackslash(sDestFolder)+sFileNameOnly(sFile);
            int nRet=::MoveFileEx(sFile.c_str(),sDestFile.c_str(),MOVEFILE_COPY_ALLOWED|MOVEFILE_REPLACE_EXISTING);
            if (nRet==0)
               {
               LPTSTR pMsg;
               if (::FormatMessage( FORMAT_MESSAGE_ALLOCATE_BUFFER|FORMAT_MESSAGE_FROM_SYSTEM,
                                    NULL,
                                    ::GetLastError(),
                                    0,
												(LPTSTR)&pMsg,
                                    0,
                                    NULL))
                  {
						nShowError(pMsg,sFile);
						::LocalFree(pMsg);
						}
					else
                  nShowError(pMsg,sFile);
               }
            }            

         }
      return bStored;
      }
   else
      return false;
}

SurfPredefDevice::SurfPredefDevice(SURF_PREDEF_LOCATION _Loc, String _sDescr, String _sExt, int _nID)
{
	Loc=_Loc;
   sDescr=_sDescr;
   sExt=_sExt;
   nID=_nID;
}

SurfPredefDevices::SurfPredefDevices()
{
   Add(SURF_NEMAS_LOC,L"NA-10",L"F_NA10",1);
   Add(SURF_NEMAS_LOC,L"Koden RadarScan",L"F_KOD",2);
   Add(SURF_NEMAS_LOC,L"Raytheon RadarScan",L"F_RAY",3);
   Add(SURF_NEMAS_LOC,L"Triton EOT",L"F_EOT",4);
   Add(SURF_NEMAS_LOC,L"Ship Info RX",L"F_SIRX",5);
   Add(SURF_NEMAS_LOC,L"EL/M 2208",L"F_ELM",6);
   Add(SURF_NEMAS_LOC,L"Cape Town ATC",L"F_CPT",7);
   Add(SURF_NEMAS_LOC,L"Resig",L"F_RES",8);
   Add(SURF_NEMAS_LOC,L"Rhubarb",L"F_RHU",9);
   Add(SURF_NEMAS_LOC,L"Phoenix",L"F_PH",10);
   Add(SURF_NEMAS_LOC,L"Sigma",L"F_SIG",11);
   Add(SURF_NEMAS_LOC,L"Minilock",L"F_MINI",12);
   Add(SURF_NEMAS_LOC,L"Real-Time Polar",L"F_RTP",13);

   Add(SURF_ITB_LOC,L"ITB ORT DCS",L"I_ORTD",0);
   Add(SURF_ITB_LOC,L"ITB ORT RCS",L"I_ORTR",1);
   Add(SURF_ITB_LOC,L"ITB MRR Track",L"I_MRRT",2);
   Add(SURF_ITB_LOC,L"ITB MRR RadarScan",L"I_MRRR",3);

   Add(SURF_FSG_LOC,L"ORT DCS",L"O_ORTD",0);
   Add(SURF_FSG_LOC,L"ORT RCS",L"O_ORTR",1);
   Add(SURF_FSG_LOC,L"MRR Track",L"O_MRRT",2);
   Add(SURF_FSG_LOC,L"MRR RadarScan",L"O_MRRRS",3);
   Add(SURF_FSG_LOC,L"BridgeMaster X Track Table",L"O_BMTX",4);
   Add(SURF_FSG_LOC,L"BridgeMaster X RadarScan",L"O_BMRX",5);
   Add(SURF_FSG_LOC,L"VTSTrack AIS",L"O_AIS",6);
   Add(SURF_FSG_LOC,L"Ship Info TX",L"O_SITX",7);
   Add(SURF_FSG_LOC,L"Real-Time Polar",L"O_RTP",8);
   Add(SURF_FSG_LOC,L"INS DCS",L"O_INS",9);
   Add(SURF_FSG_LOC,L"EOT DCS",L"O_EOT",10);
   Add(SURF_FSG_LOC,L"IFF DCS",L"O_IFF",11);
   Add(SURF_FSG_LOC,L"Landing Aid for Helicopters (Master)",L"O_BLAH",12);
   Add(SURF_FSG_LOC,L"Surface Plot",L"O_SURF",13);
   Add(SURF_FSG_LOC,L"BridgeMaster F Track Table",L"O_BMTF",14);
   Add(SURF_FSG_LOC,L"BridgeMaster F RadarScan",L"O_BMRF",15);
   Add(SURF_FSG_LOC,L"Landing Aid for Helicopters (Slave)",L"O_BLS",16);
   Add(SURF_FSG_LOC,L"GUN DCS",L"O_GUN",17);
   Add(SURF_FSG_LOC,L"CIS DCS",L"O_CIS",18);
   Add(SURF_FSG_LOC,L"RIS DCS",L"O_RIS",19);
   Add(SURF_FSG_LOC,L"Matrix DCS",L"O_MAT",20);
   Add(SURF_FSG_LOC,L"Own Ship GPS",L"O_POS",21);

   Add(SURF_209_LOC,L"Own Ship GPS",L"S_POS",0);
   Add(SURF_209_LOC,L"CSB DCS",L"S_CSB",1);
   Add(SURF_209_LOC,L"MicroNav DCS",L"S_MNAV",2);
   Add(SURF_209_LOC,L"VTSTrack AIS",L"S_AIS",3);
   Add(SURF_209_LOC,L"PL41 DCS",L"S_PL41",4);
   Add(SURF_209_LOC,L"Battery Monitor",L"S_BMS",5);
   Add(SURF_209_LOC,L"Propulsion Monitor",L"S_PROP",6);
   Add(SURF_209_LOC,L"Aggregate DCS",L"S_AGGR",7);

   Add(SURF_CST_LOC,L"CoastRad Data Hub",L"C_HUB",0);
   Add(SURF_CST_LOC,L"Constantiaberg Radar",L"CSW3",1);
   Add(SURF_CST_LOC,L"Constantiaberg AIS",L"AIS_CSW",2);
   Add(SURF_CST_LOC,L"East London ATC",L"ELA3",3);
   Add(SURF_CST_LOC,L"East London AIS",L"AIS_ELA",4);
   Add(SURF_CST_LOC,L"Kapteinskop ATC",L"KPA3",5);
   Add(SURF_CST_LOC,L"Kapteinskop AIS",L"AIS_KPA",6);
   Add(SURF_CST_LOC,L"Kareedouw ATC AIS",L"AIS_KRD",7);
   Add(SURF_CST_LOC,L"MossGas FA AIS",L"AIS_MFA",8);
   Add(SURF_CST_LOC,L"MossGas FA Radar",L"MOS3",9);
   Add(SURF_CST_LOC,L"OTB Soetmuisberg AIS",L"AIS_OTB",10);
   Add(SURF_CST_LOC,L"OTB ATC Radar",L"OVA3",11);
   Add(SURF_CST_LOC,L"Port St Johns AIS",L"AIS_PSJ",12);
   Add(SURF_CST_LOC,L"Durban ATC Radar",L"DBA3",13);
   Add(SURF_CST_LOC,L"NEMAS Koden Nav Radar",L"FBK3",14);
   Add(SURF_CST_LOC,L"Port Elizabeth ATC Radar",L"PEA3",15);
   Add(SURF_CST_LOC,L"Port Elizabeth Weather Radar",L"PEW3",16);
   Add(SURF_CST_LOC,L"Port Control Cape Town",L"VTS_CPT",17);
   Add(SURF_CST_LOC,L"Port Control Durban",L"VTS_DBN",18);
   Add(SURF_CST_LOC,L"Port Control PE",L"VTS_PEL",19);
   Add(SURF_CST_LOC,L"Port Control Richard's Bay",L"VTS_RBY",20);

   Add(SURF_CST_LOC,L"Silvermine ADSL",L"CS_SM1",40);
   Add(SURF_CST_LOC,L"Silvermine Spare",L"CS_SM2",41);
   Add(SURF_CST_LOC,L"IMT/NEMAS ADSL",L"CS_IMT1",42);
   Add(SURF_CST_LOC,L"IMT/NEMAS Spare 1",L"CS_IMT2",43);
   Add(SURF_CST_LOC,L"IMT/NEMAS Spare 2",L"CS_IMT3",44);
   Add(SURF_CST_LOC,L"DI Pretoria",L"CS_PTA1",45);

   Add(SURF_CST_LOC,L"NDF Windhoek",L"WHK",46);
   Add(SURF_CST_LOC,L"NDF Walvis Bay",L"WVB",47);

   Add(SURF_CST_LOC,L"AIS Buchu Mountain",L"AIS_BUM",50);
   Add(SURF_CST_LOC,L"AIS R�ssing Mountain",L"AIS_RGM",51);
   Add(SURF_CST_LOC,L"AIS Terrace Bay",L"AIS_TEB",52);


   Dev.Pack();
}

bool SurfPredefDevices::bImportCSV(const String sFile)
{
   JList<SurfPredefDevice> FDev;
   JFile Fil('I',JFile::ASCII_TYPE);
   JFile::FILE_ERROR E=Fil.Open(sFile);
   int nBaseOffs=-1;
   SURF_PREDEF_LOCATION Loc;
	String sDescr;
	String sExt;
   int nOffs;
   char szSt[256];
   while(!E)
      {
      E=Fil.Read(szSt,256);
      if (!E)
         {
         CommaText Txt(szSt);
         if (Txt.nGetCount()>=3)
            {
            try
               {
               if (Txt.sGetPar(1).Trim()==L"LOCATION")
                  {
                  if (Txt.sGetPar(0).Pos(L"NEMAS")>0)
                     Loc=SURF_NEMAS_LOC;
                  else if (Txt.sGetPar(0).Pos(L"ITB")>0)
                     Loc=SURF_ITB_LOC;
                  else if (Txt.sGetPar(0).Pos(L"FSG")>0)
                     Loc=SURF_FSG_LOC;
                  else if (Txt.sGetPar(0).Pos(L"209")>0)
                     Loc=SURF_209_LOC;
                  else if (Txt.sGetPar(0).Pos(L"COAST")>0)
                     Loc=SURF_CST_LOC;
                  else
                     Loc=SURF_UNKNOWN_LOC;
                  nBaseOffs=Txt.nGetVal(2);
                  }
               else if (!Txt.sGetPar(0).Trim().IsEmpty()&&!Txt.sGetPar(1).Trim().IsEmpty()&&!Txt.sGetPar(2).Trim().IsEmpty()&&(nBaseOffs>=0))
                  {
                  sDescr=Txt.sGetPar(0).Trim();
                  sExt=Txt.sGetPar(1).Trim();
                  nOffs=Txt.nGetVal(2);
                  FDev.nAdd(new SurfPredefDevice(Loc,sDescr,sExt,nBaseOffs+nOffs));
                  }
               }
            catch(...)
               {

               }
            }
         }
      }
   if (FDev.nGetCount()>0)
      {
      Dev=FDev;
      Dev.Pack();
      return true;
      }
   return false;
}

void SurfPredefDevices::Add(SURF_PREDEF_LOCATION Loc, String sDescr, String sExt, int nLocID)
{
	Dev.nAdd(new SurfPredefDevice(Loc,sDescr,sExt,Loc+nLocID));
}

int SurfPredefDevices::nFindIndex(const int nID)
{
   int nIndex=-1;
   for (int i=0; i<Dev.nGetCount(); i++)
      {
      if (Dev[i]->nID==nID)
         {
         nIndex=i;
         i=Dev.nGetCount();
         }
      }
   return nIndex;
}

int SurfPredefDevices::nFindIndex(const String sDescr, const SURF_PREDEF_LOCATION Loc)
{
	int nIndex=-1;
	for (int i=0; i<Dev.nGetCount(); i++)
		{
		if ((Dev[i]->sDescr==sDescr)&&(Dev[i]->Loc==Loc))
			{
			nIndex=i;
			i=Dev.nGetCount();
			}
		}
	return nIndex;
}

int SurfPredefDevices::nFindID(const String sDescr, const SURF_PREDEF_LOCATION Loc)
{
	int nIndex=nFindIndex(sDescr,Loc);
	if (nIndex>=0)
		return nID(nIndex);
	else
      return -1;
}

int SurfPredefDevices::nFindExtIndex(const String sExt)
{
	int nIndex=-1;
	for (int i=0; i<Dev.nGetCount(); i++)
		{
		if (Dev[i]->sExt==sExt)
			{
			nIndex=i;
			i=Dev.nGetCount();
			}
		}
	return nIndex;
}

int SurfPredefDevices::nFindExtID(const String sExt)
{
   int nIndex=nFindExtIndex(sExt);
   if (nIndex>=0)
      return nID(nIndex);
   else
      return -1;
}


String SurfPredefDevices::sDescr(const int n)
{
	return Dev[n]->sDescr;
}

String SurfPredefDevices::sExt(const int n)
{
   return Dev[n]->sExt;
}


//------------------------------------------------------------------

SurfRXClass::SurfRXClass()
{
   Init();
}

SurfRXClass::~SurfRXClass()
{
}

void SurfRXClass::Init()
{
   nMsgBufOffs=0;
   nMsgSize=-1;
   MsgState=MSG_STATE_S;
}

bool SurfRXClass::bAddByte(const BYTE uc)
{
   bool bMsgReady=false;
   switch(MsgState)
      {
      case MSG_STATE_S:
         if (uc=='S')
            MsgState=MSG_STATE_U;
         break;
      case MSG_STATE_U:
         if (uc=='U')
            MsgState=MSG_STATE_R;
         else
            MsgState=MSG_STATE_S;
         break;
      case MSG_STATE_R:
         if (uc=='R')
            MsgState=MSG_STATE_F;
         else
            MsgState=MSG_STATE_S;
         break;
      case MSG_STATE_F:
         if (uc=='F')
            MsgState=MSG_STATE_P;
         else
            MsgState=MSG_STATE_S;
         break;
      case MSG_STATE_P:
         if (uc=='P')
            MsgState=MSG_STATE_L;
         else
            MsgState=MSG_STATE_S;
         break;
      case MSG_STATE_L:
         if (uc=='L')
            MsgState=MSG_STATE_O;
         else
            MsgState=MSG_STATE_S;
         break;
      case MSG_STATE_O:
         if (uc=='O')
            MsgState=MSG_STATE_T;
         else
            MsgState=MSG_STATE_S;
         break;
      case MSG_STATE_T:
         if (uc=='T')
            MsgState=MSG_STATE_SIZE_0;
         else
            MsgState=MSG_STATE_S;
         break;
      case MSG_STATE_SIZE_0:
         nMsgSize=uc;
         nMsgBufOffs=0;
         aucMsgBuf[nMsgBufOffs++]=uc;
         MsgState=MSG_STATE_SIZE_1;
         break;
      case MSG_STATE_SIZE_1:
         nMsgSize|=(uc<<8);
         aucMsgBuf[nMsgBufOffs++]=uc;
         MsgState=MSG_STATE_SIZE_2;
         break;
      case MSG_STATE_SIZE_2:
         nMsgSize|=(uc<<16);
         aucMsgBuf[nMsgBufOffs++]=uc;
         MsgState=MSG_STATE_SIZE_3;
         break;
      case MSG_STATE_SIZE_3:
         nMsgSize|=(uc<<24);
         aucMsgBuf[nMsgBufOffs++]=uc;
         MsgState=MSG_STATE_DATA;
         break;
      case MSG_STATE_DATA:
         aucMsgBuf[nMsgBufOffs++]=uc;
         if (nMsgBufOffs==nMsgSize)
            {
            if (Msg.bCreateMsg(aucMsgBuf,nMsgSize))
               bMsgReady=true;
            MsgState=MSG_STATE_S;
            }
         break;
      default: ;
      }
   return bMsgReady;
}

SURF_REQUEST SurfRequest::AddByte(const BYTE uc)
{
   switch(MsgState)
      {
      case MSG_STATE_S:    if (uc=='S') MsgState=MSG_STATE_U;  else Init();   break;
      case MSG_STATE_U:    if (uc=='U') MsgState=MSG_STATE_R1; else Init();   break;
      case MSG_STATE_R1:   if (uc=='R') MsgState=MSG_STATE_F;  else Init();   break;
      case MSG_STATE_F:    if (uc=='F') MsgState=MSG_STATE_R2; else Init();   break;
      case MSG_STATE_R2:   if (uc=='R') MsgState=MSG_STATE_E;  else Init();   break;
      case MSG_STATE_E:    if (uc=='E') MsgState=MSG_STATE_Q;  else Init();   break;
      case MSG_STATE_Q:    if (uc=='Q') MsgState=MSG_STATE_ID; else Init();   break;
      case MSG_STATE_ID:   MsgState=MSG_STATE_REQ; nReqID=(int)uc;            break;
      case MSG_STATE_REQ:  MsgState=MSG_STATE_S;   return (SURF_REQUEST)uc;
      default: ;
      }
   return SURF_NO_REQUEST;
}



