//---------------------------------------------------------------------------

#include <jpch.h>
#pragma hdrstop

#include "SurfDevBrowseDlg.h"
#include "JUtils.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "NumEdit"
#pragma resource "*.dfm"
TSurfDevBrowseForm *SurfDevBrowseForm;
//---------------------------------------------------------------------------
__fastcall TSurfDevBrowseForm::TSurfDevBrowseForm(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TSurfDevBrowseForm::FormCreate(TObject * /*Sender*/)
{
   bImportCSV=false;
}
//---------------------------------------------------------------------------
void __fastcall TSurfDevBrowseForm::FormShow(TObject *Sender)
{
   if (bImportCSV)
      {
      String sFile=sGetExeDir()+"Surface Plot ID Master.csv";
      bool bOK=false;
      if (bFileExist(sFile))
         bOK=Dev.bImportCSV(sFile);
      if (!bOK)
         nShowInfo(L"Cannot Import Surface Plot ID's",L"Error Reading "+sFile+"\nUsing Default Surface Plot ID's");
      }
   int nIndex=Dev.nFindIndex(nID);
   if (nIndex>=0)
      {
      NEMASRad->Checked=(Dev.Location(nIndex)==SURF_NEMAS_LOC);
      ITBRad->Checked=(Dev.Location(nIndex)==SURF_ITB_LOC);
      FSGRad->Checked=(Dev.Location(nIndex)==SURF_FSG_LOC);
      T209Rad->Checked=(Dev.Location(nIndex)==SURF_209_LOC);
      CstRad->Checked=(Dev.Location(nIndex)==SURF_CST_LOC);
      }
   else
      NEMASRad->Checked=true;
   if (NEMASRad->Checked)
      NEMASRadClick(Sender);
   else if (ITBRad->Checked)
      ITBRadClick(Sender);
   else if (FSGRad->Checked)
      FSGRadClick(Sender);
   else if (T209Rad->Checked)
      T209RadClick(Sender);
   else
      CstRadClick(Sender);
   DevLBClick(Sender);
   OKBut->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TSurfDevBrowseForm::FormClose(TObject * /*Sender*/,
      TCloseAction & /*Action*/)
{
//
}
//---------------------------------------------------------------------------
void __fastcall TSurfDevBrowseForm::FormDestroy(TObject * /*Sender*/)
{
//
}
//---------------------------------------------------------------------------
void __fastcall TSurfDevBrowseForm::NEMASRadClick(TObject *Sender)
{
   DevLB->Clear();
   Location=SURF_NEMAS_LOC;
   int nCurrent=-1;
   for (int i=0; i<Dev.nCount(); i++)
      {
      if (Dev.Location(i)==Location)
         {
         DevLB->Items->Add(Dev.sDescr(i));
         if (Dev.nID(i)==nID)
            nCurrent=DevLB->Items->Count-1;
         }
      }
   DevLB->ItemIndex=nCurrent;
   DevLBClick(Sender);
}
//---------------------------------------------------------------------------
void __fastcall TSurfDevBrowseForm::ITBRadClick(TObject *Sender)
{
   DevLB->Clear();
   Location=SURF_ITB_LOC;
   int nCurrent=-1;
   for (int i=0; i<Dev.nCount(); i++)
      {
      if (Dev.Location(i)==Location)
         {
         DevLB->Items->Add(Dev.sDescr(i));
         if (Dev.nID(i)==nID)
            nCurrent=DevLB->Items->Count-1;
         }
      }
   DevLB->ItemIndex=nCurrent;
   DevLBClick(Sender);
}
//---------------------------------------------------------------------------
void __fastcall TSurfDevBrowseForm::FSGRadClick(TObject *Sender)
{
   DevLB->Clear();
   Location=SURF_FSG_LOC;
   int nCurrent=-1;
   for (int i=0; i<Dev.nCount(); i++)
      {
      if (Dev.Location(i)==Location)
         {
         DevLB->Items->Add(Dev.sDescr(i));
         if (Dev.nID(i)==nID)
            nCurrent=DevLB->Items->Count-1;
         }
      }
   DevLB->ItemIndex=nCurrent;
   DevLBClick(Sender);
}
//---------------------------------------------------------------------------
void __fastcall TSurfDevBrowseForm::DevLBClick(TObject * /*Sender*/)
{
   int n=DevLB->ItemIndex;
   if (n>=0)
      {
      int nIndex=Dev.nFindIndex(DevLB->Items->Strings[n],Location);
      if (nIndex>=0)
         {
         nID=Dev.nID(nIndex);
         sDescr=Dev.sDescr(nIndex);
         sExt=Dev.sExt(nIndex);
         ExtEd->Text=sExt;
         IDEd->SetVal(nID);
         }
      }
}
//---------------------------------------------------------------------------
void __fastcall TSurfDevBrowseForm::T209RadClick(TObject *Sender)
{
	DevLB->Clear();
	Location=SURF_209_LOC;
	int nCurrent=-1;
	for (int i=0; i<Dev.nCount(); i++)
		{
		if (Dev.Location(i)==Location)
			{
			DevLB->Items->Add(Dev.sDescr(i));
			if (Dev.nID(i)==nID)
				nCurrent=DevLB->Items->Count-1;
			}
		}
	DevLB->ItemIndex=nCurrent;
	DevLBClick(Sender);
}
//---------------------------------------------------------------------------

void __fastcall TSurfDevBrowseForm::CstRadClick(TObject *Sender)
{
	DevLB->Clear();
	Location=SURF_CST_LOC;
	int nCurrent=-1;
	for (int i=0; i<Dev.nCount(); i++)
		{
		if (Dev.Location(i)==Location)
			{
			DevLB->Items->Add(Dev.sDescr(i));
			if (Dev.nID(i)==nID)
				nCurrent=DevLB->Items->Count-1;
			}
		}
	DevLB->ItemIndex=nCurrent;
	DevLBClick(Sender);
}
//---------------------------------------------------------------------------

void __fastcall TSurfDevBrowseForm::DevLBDblClick(TObject *Sender)
{
	DevLBClick(Sender);
	ModalResult=mrOk;
}
//---------------------------------------------------------------------------

